% This file sorts the output of SAGE NonIdeal MassBalance model and creates
% graphs with literature comparison fluxes

clear all
%% SAGE Model Parameters and Outputs

SAL = 34; % specify salinity
% load model output .mat file 
% load dT_-3_results_RH_90_4pH.mat

load all_data_mss.mat WND EDS FP HS MSS US WCC % includes mean squared wave slope and up to 50 m/s winds
g=9.8; %m/s^2, gravity
CP=g./(2*pi.*FP);% peak phase speed.
WAGE=CP./US; % compute wave age: cp/u*
WaveData=[WND WAGE CP EDS FP HS MSS US WCC];

%% Literature Flux Calculations

% Inputs
MMG_CO2=44.01; % molecular mass of CO2 in g/mol
P= 1000;        % Barometric Pressure (mb)
RHOA=1.2922*(273.15/(273.15 + TairC))*(P/1013.25); % Air density kg/m³
Sc=2073.1-(125.62.*TwC)+(3.6276.*TwC.^2)-(0.043219.*TwC.^3); % T-dependent Sc number from Wan 1992
airCO2_ppm=420; % Keeling curve
% dCO2_frac=(382-airCO2_ppm).*(1E-6); % fractional air-sea difference in pCO2
dCO2_frac=(seaCO2_ppm-airCO2_ppm).*(1E-6); % fractional air-sea difference in pCO2

% (Nightingale et al 2000b)
N00_U10=0:16; % m/s
N00_K600=0.24.*(N00_U10.^2)+(0.061.*N00_U10); % cm/hr
N00_K660=((Sc./660).^-0.5).*(N00_K600./((Sc./600).^-0.5));
N00_FCO2=N00_K660./(100*60*60).*dCO2_frac; % m/s

% (McGillis et al 2001)
MG01_U10=0:20; % m/s
MG01_K660=3.3+0.026.*MG01_U10.^3; % cm/hr
MG01_FCO2=MG01_K660./(100*60*60).*dCO2_frac; % m/s

% (Ho et al 2006)
H06_U10=0.6:23.5; % m/s
H06_K600=0.266.*H06_U10.^2; % cm/hr
H06_K660=((Sc./660).^-0.5).*(H06_K600./((Sc./600).^-0.5));
H06_FCO2=H06_K660./(100*60*60).*dCO2_frac; % m/s

% (Wanninkhof et al 2014)
W14_K660 = 0.251.*MG01_U10.^2.*(Sc/660).^-0.5; % cm/hr
W14_FCO2=W14_K660./(100*60*60).*dCO2_frac; % m/s


%% Separating positive and negative fluxes:

% positive fluxes are EVASION, negative fluxes are INVASION
% evasion is closed symbols, invasion is open symbols
NetFlux_A98 = SSGF_Outputs(:,2); NetFlux_B22 = SSGF_Outputs(:,1);

% A98
A98idx = NetFlux_A98<0; % create logical index of negative values
A98neg = NetFlux_A98(A98idx)'; % pull negative values
A98pos = NetFlux_A98(~A98idx)'; % pull positive values

A98_U10=WaveData(wave_ind,1); % repeat for U10 values
A98_U10neg= A98_U10(A98idx);
A98_U10pos= A98_U10(~A98idx);

WAGE_A98=WaveData(wave_ind,2);
WAGE_A98neg=WAGE_A98(A98idx); % repeat
WAGE_A98pos=WAGE_A98(~A98idx);


% B22
B22idx = NetFlux_B22<0; % create logical index of negative values
B22neg = NetFlux_B22(B22idx)'; % pull negative values
B22pos = NetFlux_B22(~B22idx)'; % pull positive values

B22_U10=WaveData(wave_ind,1); % repeat for U10 values
B22_U10neg= B22_U10(B22idx);
B22_U10pos= B22_U10(~B22idx);

WAGE_B22=WaveData(wave_ind,2);
WAGE_B22neg=WAGE_B22(B22idx); % repeat
WAGE_B22pos=WAGE_B22(~B22idx);

%% Independent Loglog Plots for Influx and Efflux

figure
ax(1)=subplot(2,1,1);
a98=plot(A98_U10pos,A98pos,"b:");
% a98=scatter(A98_U10pos,A98pos,500,WAGE_A98pos,'*');
hold on
b22=scatter(B22_U10pos,B22pos,500,WAGE_B22pos,'.');
% mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
% w14=plot(MG01_U10,abs(W14_FCO2),"r-");
% n00=plot(N00_U10,abs(N00_FCO2),"b-");
% h06=plot(H06_U10,abs(H06_FCO2),"k--");
% z23=scatter(Z23_U10,abs(Z23_FCO2),40,WaveData(wave_ind,2),'^');
% l18=scatter(L18_U10,abs(L18_FCO2),40,L18_WAGE,'d',"filled");
xlim([1 50])
xlabel("Wind Speed (m/s)")
ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
title("Net CO2 Efflux")
% legend([a98 b22],"A98 SAGE","B22 SAGE")
% legend([a98 mg01 w14 n00 h06 z23 l18],"A98 SAGE","MG01","W14","N00","H06","Z23","L18")
% legend([a98 mg01 w14 n00 h06 l18],"A98 SAGE","MG01","W14","N00","H06","L18")
% set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')

cc=colorbar;
caxis([15 47]);
cc.Label.String='c_p/u_*';
hold off

% B22
ax(2)=subplot(2,1,2);
b22 = scatter(B22_U10neg,abs(B22neg),50,WAGE_B22neg,'o');
hold on
a98= plot(A98_U10neg,abs(A98neg),"b:");
% a98= scatter(A98_U10neg,abs(A98neg),50,WAGE_A98neg,'*');
mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
w14=plot(MG01_U10,abs(W14_FCO2),"r-");
n00=plot(N00_U10,abs(N00_FCO2),"b-");
h06=plot(H06_U10,abs(H06_FCO2),"k--");
% z23=scatter(Z23_U10,abs(Z23_FCO2),40,WaveData(wave_ind,2),'^');
% l18=scatter(L18_U10,abs(L18_FCO2),40,L18_WAGE,'d');
xlim([1 50])
xlabel("Wind Speed (m/s)")
ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
title("Net CO2 Influx")
% legend([b22 a98 mg01 w14 n00 h06 z23 l18],"B22 SAGE","A98 SAGE", "MG01", "W14","N00","H06","Z23","L18")
% legend([b22 mg01 w14 n00 h06 l18],"B22 SAGE","MG01", "W14","N00","H06","L18")
% set(gca, 'XScale', 'log')

set(gca, 'YScale', 'log')
set(gca,'Ydir','reverse')
cc=colorbar;
caxis([15 47]);
cc.Label.String='c_p/u_*';
hold off

% linkaxes(ax,'xy')
% 
% savefig("SAGEv2_NonIdeal_3dT_80RH_DualPlot")

%% Single Figure 

figure
b22=scatter(B22_U10pos,B22pos,50,WAGE_B22pos,'o',"filled");
hold on
scatter(B22_U10neg,abs(B22neg),50,WAGE_B22neg,'o')

a98=plot(A98_U10pos(1:126),A98pos(1:126),'k.-');
plot(A98_U10neg,abs(A98neg),'ko-')

mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
w14=plot(MG01_U10,abs(W14_FCO2),"r-");
n00=plot(N00_U10,abs(N00_FCO2),"b-");
h06=plot(H06_U10,abs(H06_FCO2),"k--");
% z23=scatter(Z23_U10,abs(Z23_FCO2),40,WaveData(wave_ind,2),'^');
% l18=scatter(L18_U10,abs(L18_FCO2),40,L18_WAGE,'d');
xlabel("Wind Speed (m/s)")
ylabel("Net CO_2 Flux (kg CO_2/kg air * m/s)")
title("Net CO_2 Flux: Spray vs Interfacial")
% legend([a98 b22 mg01 w14 n00 h06 z23 l18], "A98","B23/WW3","MG01", "W14","N00","H06","Z23","L18")
legend([a98 b22 mg01 w14 n00 h06], "A98","B23/WW3","MG01", "W14","N00","H06")
set(gca, 'YScale', 'log')
box on
cc=colorbar;
caxis([15 47]);
cc.Label.String='c_p/u_*';
ylim([1e-12 1e-3])
hold off
% savefig("SAGEv2_NonIdeal_3dT_80RH_singlefig")

%% Spectral Net Flux- varies by wave ind
% this gives curves over the r0 distribution

% pull from drop net kin flux/evaporation outputs- rows are r0s, columns are variables, pages
% are wave inds
wave_ind_subset = (5:18:153); % fifth WAGE for every other windspeed (9 WAGEs per U10)
r0 = Evaporation_Outputs(:,1,1); 
ss_drop_flux = squeeze(Droplet_Net_KinFlux_Outputs(:,1,wave_ind_subset)); 
u10_drop_flux = squeeze(Droplet_Net_KinFlux_Outputs(:,2,wave_ind_subset));

figure; 
subplot(1,2,1); 
plot(r0,ss_drop_flux); ax(1) = gca;
title('sea state'); xlabel('r0 \mum'); ylabel('Net Kinematic Flux for Each r0 (kg CO2/drop)/(kg air/m3)')
subplot(1,2,2); plot(r0,u10_drop_flux); ax(2) = gca;
title('u10 only'); linkaxes(ax,'xy')

% SSGFS Number of Droplets
% compute SSGFs
reduced_wave_ind = wave_ind(wave_ind_subset);
% compute SSGFs numdrop for each series, plot that
for c = 1:length(reduced_wave_ind)
    % Barr22 SSGF: m3/(m2 s um)
    Barr22(c,:)=volfluxB22ww3(r0',FP(reduced_wave_ind(c)),EDS(reduced_wave_ind(c)),WND(reduced_wave_ind(c)),WCC(reduced_wave_ind(c)),...
    HS(reduced_wave_ind(c)),US(reduced_wave_ind(c)),MSS(reduced_wave_ind(c)),TairC,TwC,SAL,P,RH);

    % A98 SSGF: m3/(m2 s um)
    A98(c,:)=volfluxA98(r0',WND(reduced_wave_ind(c)));
end

% Plot upscaled flux vs r0. Compare results from SSGFs
VOL_inital_um3 = (4/3).*pi.*r0.^3;
VOL_initial_m3 = VOL_inital_um3'.*(1E-6).^3; 
% vector where each number is the inital droplet volume for each size class

% Number of droplets lifted for each r0 by SSGF
Num_B22=Barr22./VOL_initial_m3; % (m3/(m2 s um))./(m3/drop) = (drop/(m2 s um))
Num_A98=A98./VOL_initial_m3;

figure; 
subplot(1,2,1); 
loglog(r0,Num_B22'); ax(1) = gca;
title('sea state'); xlabel('r0 \mum'); ylabel('Number of Drops Lifted (drop/(m2 s \mum)')
subplot(1,2,2); loglog(r0,Num_A98'); ax(2) = gca;
title('u10 only'); linkaxes(ax,'xy')

% Spectral Net Flux over Droplet Size
% multiply SSGFs numdrop times net flux for each size class, plot that
b22_drop_flux = Num_B22' .* ss_drop_flux;
a98_drop_flux = Num_A98' .* u10_drop_flux;

colors = lines(10);  % Distinct colors per series

figure;

% First subplot
subplot(1,2,1);
hold on;
for i = 1:size(b22_drop_flux,2)
    b22 = b22_drop_flux(:,i);
    idx_pos = b22 > 0;
    idx_neg = b22 < 0;

    loglog(r0(idx_pos), b22(idx_pos), '-',  'Color', colors(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('B22-%d (+)', i));
    loglog(r0(idx_neg), abs(b22(idx_neg)), '--',  'Color', colors(i,:), 'LineWidth', 1.5,'DisplayName', sprintf('B22-%d (-)', i));
end
set(gca, 'XScale', 'log', 'YScale', 'log');
title('B22');
xlabel('r0 \mum');
ylabel('Net Kinematic Flux for Each r0 (kg CO2/drop)/(kg air/m3)');
grid on;
ax(1) = gca;

% Second subplot
subplot(1,2,2);
hold on;
for i = 1:size(a98_drop_flux,2)
    a98 = a98_drop_flux(:,i);
    idx_pos = a98 > 0;
    idx_neg = a98 < 0;

    loglog(r0(idx_pos), a98(idx_pos), '-',  'Color', colors(i,:), 'LineWidth', 1.5 ,'DisplayName', sprintf('A98-%d (+)', i));
    loglog(r0(idx_neg), abs(a98(idx_neg)), '--',  'Color', colors(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('A98-%d (-)', i));
end
set(gca, 'XScale', 'log', 'YScale', 'log');
title('A98');
xlabel('r0 \mum');
ylabel('Net Kinematic Flux for Each r0 (kg CO2/drop)/(kg air/m3)');
grid on;
ax(2) = gca;

% Link axes
linkaxes(ax, 'xy');

% Optional: Add legends
% legend(ax(1), 'show'); legend(ax(2), 'show');


%% Save Postprocessed .mat file

    filename = sprintf('prcsd_dT_%g_results_RH_%g_4pH.mat',dT, RH);
    save(filename)

