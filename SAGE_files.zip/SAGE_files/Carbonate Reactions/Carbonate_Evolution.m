function [t,r,S,T,VOL,r_EQ,TAU_F, U10_TAU_F,TA,DIC,pH,pCO2,fCO2,HCO3,CO3,...
    CO2,genCO2,CO2_Flux_Evol_umol,KinCO2Flux_alft,KinCO2Flux_u10_alft,...
    kd_660_evol,kd_660,kd_660_u10] = Carbonate_Evolution(r0,TwC,TairC,...
    RH,SAL,P,DIC_initial,pH_initial,wave_ind,HS,WND,US,atmCO2_ppm,seaCO2_ppm)

%% Andreas Microphysical Model Calculations

% Input Variables w example values

% r0 = Initial radius of the droplet (μm)
% TwC = Water temperature (°C)
% TairC = Air Temperature (°C)
% RH = Relative humidity in %
% pH_initial = Initial pH
% DIC_initial = Initial DIC value
% SAL = Salinity 
% P = Barometric Pressure (mb)
% seaCO2_ppm = 386; % Pulled from https://explore.webodv.awi.de/ocean/carbon/socat/socatv2024/
% atmCO2_ppm = 410; % Pulled from Keeling Curve

% calcualate timesteps
t = get_logarithmic_times(0.01,10000,1.1); % time of droplet evolution in seconds, spaced logarithmically

% Running the microphysical model

[TEQ, TAU_T, r_EQ, TAU_R, SALEQ] = A17_microphys_drop_evol(r0,TwC,TairC,SAL,P,RH);

% Calculating microphysical evolution curves from final and initial model conditions

T =  TEQ + exp(-t./TAU_T).*(TwC - TEQ);           % Thermal evolution curve (C)
r = r_EQ + exp(-t./TAU_R).*(r0 - r_EQ);           % Radial evolution curve (um)
S =  SAL+(1- exp(-t./TAU_R)).*(SALEQ - SAL);      % Salinity evolution curve (psu)
VOL = (4/3).*pi.*(r.^3);                          % Volume evolution curve in um^3, assumes perfect sphere
VOL_m3 = VOL .* ((1e-6).^3);                      % Volume evolution curve in m^3

t=t';r=r';S=S';T=T'; % transposes microphysical parameters from row to col vector for function output

rhow = zeros(1,length(t));
% Density of seawater %kg/m³
for n = 1:length(t)
    rho0= 999.842594 + 6.793952e-2.*T(n) - 9.095290e-3.*T(n).^2 + 1.001685e-4.*T(n).^3 - 1.120083e-6.*T(n).^4 + 6.536332e-9.*T(n).^5; % (kg m-3) 
    A = 8.24493e-1 - 4.0899e-3.*T(n) + 7.6438e-5.*T(n).^2  - 8.2467e-7.*T(n).^3 + 5.3875e-9.*T(n).^4;
    B = -5.72466e-3 + 1.0227e-4.*(n) - 1.6546e-6.*T(n).^2;
    C = 4.8314e-4;
    rhow(n) = A.*S(n) + B.*S(n).^(3/2) + C.*S(n).^2 + rho0;
end

MASS_kg = VOL_m3 .* rhow; % kg of seawater in the droplet

%% CO2 Gas Concentration from Henry's Constant Under Changing Temperature and Salinity

% This section computes Henry's Constant for CO2 using the Weiss 1974 eq 12:

% Weiss Table 1 Constants for Eq 12 (below) in units of mol/L/atm
A1w = -58.0931; A2w = 90.5069; A3w = 22.2940; 
B1w = 0.027766; B2w = -0.025888; B3w = 0.0050578;

% Weiss 1974 Eq 12 calculating Henry's Law Constant for CO2 for evolving
% salinity and temperature within evolving droplet.
% The concentration of dissolved CO2 and fCO2,the fugacity of  gaseous CO2,  
% then obey the equation [CO2] = K0 × fCO2, where the fugacity is
% virtually equal to the partial pressure, pCO2 (within ~1%). 
KH = zeros(1,length(t));
for b=1:length(t) 
    % calculate KH
    KH(b) = exp(A1w + A2w.*(100./(T(b)+273.15)) + A3w.*log((T(b)+273.15)./100) + ...
        S(b).*(B1w + B2w.*((T(b)+273.15)./100) + B3w.*((T(b)+273.15)./100).^2));
end

%% CO2SYS Inputs and Surface Water Carbonate System Snapshot

% SAL = S;              % Salinity 
% TEMPIN = T;           % (degr. C) 
TEMPOUT = nan;        % (degr. C) 
PRESIN = 0;           % (dbar) 
PRESOUT = nan;        % (dbar) 
SI = 2;            % (umol/kgSW) 
% SI = 40.3;            % (umol/kgSW) %Nutrient data from OAZ data in Table 1 in Smith et al 2022
PO4 = 2;              % (umol/kgSW) 
NH4 = 0.52;           % (umol/kgSW) 
H2S = 0;              % (umol/kgSW) 
pHSCALEIN =  1;       % (Total Scale)
K1K2CONSTANTS= 18;    % (Papadimitriou et al, 2018, T:-6 to 25 C S:35 to 100. Total scale. 
                      %  Real and artificial seawater.)
KSO4CONSTANT = 1;     % 1 = KSO4 of Dickson   (PREFERRED)
KFCONSTANT = 2;       % 2 = KF of Perez & Fraga, 1987  (PREFERRED)
BORON = 2;            % 2 = TB of Lee 2010  (PREFERRED)

D(1,:) = CO2SYS_hypersaline(DIC_initial,pH_initial,2,3,S(1),T(1),TEMPOUT,PRESIN, ...
    PRESOUT,SI,PO4,NH4,H2S,pHSCALEIN,K1K2CONSTANTS,KSO4CONSTANT,KFCONSTANT,BORON);

% Numerical indicators for CO2SYS input parameters (PAR1 and PAR2)
% Also column numbers where each variable is stored in the output matrix D 
%  1 = TA      total alkalinity                      (umol/kgSW)
%  2 = DIC     sum of all carbonate species present  (umol/kgSW)
%  3 = pH      pH of the water                       (pH units)
%  4 = pCO2    partial pressure of CO2 gas           (uatm)
%  5 = fCO2    fugacity of CO2 gas in the water      (uatm)
%  6 = HCO3    bicarbonate present                   (umol/kgSW)
%  7 = CO3     carbonate present                     (umol/kgSW)
%  8 = CO2     CO2 present                           (umol/kgSW)

%% Indices of Thermal Equilibrium

% Locate temperature changes
dT = diff(T); % first derivative of temperature vector
change_indices = find(dT ~= 0);

if isempty(change_indices)
    disp('No change detected');
    start_idx = [];
    end_idx = [];
else
    start_idx = change_indices(1);
    end_idx = change_indices(end);
end

%% External DIC Modification using CO2 Gas Concentration
% This loop works in concentrations of umol/kg and masses of umol
% The carbonate system responds to T, S, and CO2 gas changes but mostly to pH 

pH = pH_initial; DIC_conc_prev = DIC_initial; 
CO2_flux_umol = zeros(1,length(t));
for i = 2:length(t)

    % Runs the CO2SYS model for the salinity and evolution curves
    D(i,:) = CO2SYS_hypersaline(DIC_conc_prev,pH,2,3,S(i),T(i),TEMPOUT,PRESIN,PRESOUT,SI,PO4,...
        NH4,H2S,pHSCALEIN,K1K2CONSTANTS,KSO4CONSTANT,KFCONSTANT,BORON); 
    coeff = 4.5; % A coeff value of 1 drops pH to 7.2, 4.5 drops pH to 4
    pH = pH_initial - coeff.*(3.*log10(r(1)./r(i))); % models pH drop observed by Angle et al 2021 (spray pH ~ 4)
   
    % Calculate CO2 gas flux from CO2SYS output
    % Assumes instantaneous equilibration with atmosphere (Andreas et al 2017)
    if i >= start_idx && i <= end_idx
        dpCO2 = D(i,4)-atmCO2_ppm; % uatm, allows for influx during thermal equilibrium
    else
        dpCO2 = (max(D(i,4) - atmCO2_ppm,0)); 
        % uatm, allows only for efflux during radial equilibrium, prevents influx after all carbon leaves
    end

    % DIC mass change due to gas flux
    CO2_flux_umol(i) = dpCO2 * KH(i) * MASS_kg(i); % µmol of CO2 lost/gained
    DIC_mass_prev = D(i,2) * MASS_kg(i); % Total DIC mass (µmol)

    DIC_mass_next = DIC_mass_prev - CO2_flux_umol(i); % change in DIC mass 

    % Reset for next loop
    DIC_mass_prev = DIC_mass_next; % µmol rename value for next iteration
    % convert mass change to concentration so it can go back into CO2SYS
    DIC_conc_prev = DIC_mass_prev./MASS_kg(i); 

end

    TA = D(:,1);     % Extracts new Alk value 
    DIC = D(:,2);     % Extract new DIC value 
    pH = D(:,3);      % Extract new pH value 
    pCO2 = D(:,4);    % Extracts new pCO2 value 
    fCO2 = D(:,5);     % Extracts new fCO2 value 
    HCO3 = D(:,6);     % Extracts new HCO3- value 
    CO3 = D(:,7);     % Extracts new CO3 2- value 
    CO2 = D(:,8);     % Extracts new CO2 value (umol/kg)
    genCO2 = DIC_initial-D(:,2);   % CO2 generated from DIC changes
    CO2_Flux_Evol_umol = CO2_flux_umol; %    % Droplet mass flux evolution in umol 

    %% Time Aloft (tau_f)
% droplet time aloft for both sea state and wind only parameterizations
[TAU_F] = TAU_F_Vd(r0,WND(wave_ind),HS(wave_ind),US(wave_ind),TairC,TwC,P);
idx_alft=find(t<=TAU_F); % find where the total time is less than the time aloft
idx_alft=idx_alft(end); % choose the last instance

U10_TAU_F = TAU_F_WND_ONLY(r0,WND(wave_ind),TairC,TwC,P);
u10_idx_alft=find(t<=U10_TAU_F); % find where the total time is less than the time aloft
u10_idx_alft=u10_idx_alft(end); % choose the last instance

%% Net Flux Evolution

MMG_CO2 = 44.01; % molecular mass of CO2 in g/mol
RHOA = 1.2922*(273.15/(273.15 + TairC))*(P/1013.25); % Air density in kg/m³
% RHOA = 1.2041; %kg/m³    % density of air at 20C, reference value

    % Calculate Kinematic Flux at each timestep
    % Flux unit conversion from umols lost to mols lost
    MssFluxEvol_mol = CO2_Flux_Evol_umol.*1E-6; % single droplet net mass flux at sea state time aloft (mol CO2/drop)

    % Flux unit conversion from mols CO2 lost to kg CO2 lost
    MssFluxEvol_kg=MssFluxEvol_mol.*MMG_CO2.*(1E-3); % converts mol CO2/drop to kg CO2/drop 
    
    % Unit Conversion from Mass Flux to Kinematic Flux
    KinFluxEvol=MssFluxEvol_kg./RHOA; % converts mass flux to kinematic flux (kg CO2/drop)/(kg air/m3)

    % Interpolates value of kinematic flux at exactly time aloft
    KinFlux_interp = interp1(t, KinFluxEvol, TAU_F, 'linear');
    KinFlux_interp_u10 = interp1(t, KinFluxEvol, U10_TAU_F, 'linear');

    % Integrates kinematic flux from start to interpolated value at exactly time aloft
    KinCO2Flux_alft = trapz(t(t <= TAU_F), KinFluxEvol(t <= TAU_F)) + (TAU_F - t(idx_alft)) * KinFlux_interp;
    KinCO2Flux_u10_alft = trapz(t(t <= U10_TAU_F), KinFluxEvol(t <= U10_TAU_F)) + (U10_TAU_F - t(u10_idx_alft)) * KinFlux_interp_u10;

%% K660: Gas Transfer Velocity Evolution and Net Transfer Velocity
    % Calculate Sc using the equation in the Appendix of Wanninkhof 1992: 
   
    Sc=2073.1-(125.62.*T)+(3.6276.*T.^2)-(0.043219.*T.^3);
    Sc_660=(Sc./660).^0.5; % Standardization factor for gas transfer velocity (kd)
    % does not account for salinity spike- not sure if it is useful

    % Calculates the difference in the pCO2 between the ocean and the atmosphere
    % in fractional units (1E-6 factors convert ppm to fractional units)
    dCO2=abs(seaCO2_ppm.*1E-6-atmCO2_ppm.*1E-6); % used in K660 calculations
   
    % Calculate Effective K660 for droplet-mediated CO2 flux:
    kd_660_evol=KinFluxEvol'./(dCO2.*1E-6)./(Sc_660).*100.*3600; 

    % interpolates value of k660 at exactly time aloft
    kd660_interp = interp1(t, kd_660_evol, TAU_F, 'linear');
    kd660_interp_u10 = interp1(t, kd_660_evol, U10_TAU_F, 'linear');

    % integrates k660 from start to interpolated value at exactly time aloft
    kd_660 = trapz(t(t <= TAU_F), kd_660_evol(t <= TAU_F)) + (TAU_F - t(idx_alft)) * kd660_interp;
    kd_660_u10 = trapz(t(t <= U10_TAU_F), kd_660_evol(t <= U10_TAU_F)) + (U10_TAU_F - t(u10_idx_alft)) * kd660_interp_u10;
    
end