function [snr] = volfluxB22ww3(r0,FP,EDS,WND,WCC,HS,US,MSS,TairC,TwC,SAL,P,RH)

% Barr et al 2023 Eq 1 using WW3 model data
% units m3 m-2 s-1 um-1
% Divided by seawater density to convert mass flux to vol flux
% WCC data from WW3 replaces the Barr23 Wss equation for whitecap coverage. 

% FP is peak frequency
% EDS is energy dispersion
% WND is wind speed at 10 m
% WCC is whitecap coverage
% HS is significant wave height
% US is friction velocity
% T is the seasurface temp in c
% S is the salinity 
% Pmpa is the atm pressure in MPa (Pa/1e6)
% TwC Water temperature (°C) from https://explore.webodv.awi.de/ocean/carbon/socat/socatv2024/
% TairC Air Temperature (°C)
% RH Relative humidity in %
% SAL Salinity 
% P Barometric Pressure (mb)

MSS = 0.01+MSS.*1.5; % correction factor from Davis et al 2023 
zt=1; % height of observation in m
T2K  = 273.16; % converts C to K

snr=zeros(size(r0));

% Equation Coefficients
C1=4.05; 
C2=0.1295;
C3=0.89875;
C4=2.17;
C5=0.852;
fs=2.2;

% Density of air %kg/m³
Tf=-0.0575*SAL+1.71052E-3*SAL.^1.5-2.154996E-4*SAL.*SAL; %freezing point of seawater
P_tq = P - (0.125*zt); % P at tq measurement height (mb)
[Q]  = qsat26air(TairC,P_tq,RH); % specific humidity of air (g/kg).
    % Assumes rh relative to ice T<0
    % Pv is the partial pressure due to water vapor in mb
Q=Q./1000;  % change Q to g/g
P_tq = P - (0.125*zt); % P at tq measurement height (mb)
Rgas = 287.1;
rhoa = P_tq*100./(Rgas*(TairC+T2K).*(1+0.61*Q));

% Density of seawater %kg/m³
rho0= 999.842594 + 6.793952e-2.*TwC - 9.095290e-3.*TwC.^2 + 1.001685e-4.*TwC.^3 - 1.120083e-6.*TwC.^4 + 6.536332e-9.*TwC.^5; % (kg m-3) 
A = 8.24493e-1 - 4.0899e-3.*TwC + 7.6438e-5.*TwC.^2  - 8.2467e-7.*TwC.^3 + 5.3875e-9.*TwC.^4;
B = -5.72466e-3 + 1.0227e-4.*TwC - 1.6546e-6.*TwC.^2;
C = 4.8314e-4;
rhow = A.*SAL + B.*SAL.^(3/2) + C.*SAL.^2 + rho0;

% Viscosity of Seawater 
 S = SAL/1000;
    a = [1.5700386464E-01; 6.4992620050E+01; -9.1296496657E+01; 4.2844324477E-05;...
         1.5409136040E+00; 1.9981117208E-02; -9.5203865864E-05; 7.9739318223E+00;...
        -7.5614568881E-02; 4.7237011074E-04];
    mu_w = a(4) + 1./(a(1)*(TwC+a(2)).^2+a(3));
    A  = a(5) + a(6) * TwC + a(7) * TwC.^2;
    B  = a(8) + a(9) * TwC + a(10)* TwC.^2;
    mu = mu_w.*(1 + A.*S + B.*S.^2);
    vw  = mu./rhow; % m2/s

% Surface Tension of Seawater - Nayar 2014
gamma_w = (235.8.*(1-((TwC+T2K)/647.096)).^1.256).*(1-0.625.*(1-((TwC+T2K)/647.096)));
a1 = 3.766e-4; % kg/g
a2 = 2.347e-6; % kg/gC
mgamma = gamma_w.*(1+a1.*SAL+a2.*SAL.*TwC);
gamma = mgamma./1000;  % N/m
sigma= gamma/rhow; % m3/s2

% Kinematic viscosity of Air
va = 1.326e-5*(1+6.542e-3.*TairC+8.301e-6*TairC.^2-4.84e-9*TairC.^3); %m2/s

% Constants
alpha=0.54; %Kolmogorov's constant
g=9.8; %m/s2 %gravity
k=0.4; %von karman constant

CP=g./(2*pi.*FP);% peak phase speed.
z0=10./exp(k.*WND./US);
hh=200.*z0;
Uh=US./k*log(hh./z0);

Uhrel=Uh-0.8.*CP; % from B23 under Eq 1. 
sigmau=WND;  % std dev of wind speed

ebar=(100.*EDS)/(HS.*rhow.*WCC); %volumetric kinematic dissipation rates, m2/s3
etak=((vw.^3)./(ebar)).^(0.25); %kolmogorov microscale on the waterside

% Pruppacher and Klett 1975 Polynomial Fall Speed 
% (10 < r0 < 535 um) 
CDNre2 = (32.*((r0.*1e-6).^3).*(rhow-rhoa).*g)./(3.*rhoa.*va.^2); % eq 10-108
X = log(CDNre2); % noted in text
B0=-3.18657; B1=0.992696; B2=-0.153193E-2; B3=-0.987059E-3; B4=-0.578878E-3;
B5=0.855176E-4; B6=-0.327815E-5;
Y = B0 + B1.*X + B2.*X.^2 + B3.*X.^3 + B4.*X.^4 + B5.*X.^5 + B6.*X.^6; % eq 10-111
Nre = exp(Y);  % noted in text
Vf_1=(va.*Nre)./(2.*(r0.*1e-6));

% (535 < r0 < 3500 um)
% multiply all va by rhoa to convert to nonkinematic
% direct from Beard 1976
NP = gamma.^3 .*rhoa.^2./(va.^4.*rhoa.^4.*g.*(rhow-rhoa));
C_3 = 4.*(rhow-rhoa).*g/(3*gamma);
Bo = C_3.*((2*r0.*1e-6).^2);
X_2=log(Bo.*NP.^(1/6));
B0_2=-5.00015; B1_2=5.23778; B2_2=-2.04914; B3_2=0.475294; B4_2=-0.542819E-1; B5_2=0.238449E-2;
Y_2 = B0_2 + B1_2.*X_2 + B2_2.*X_2.^2 + B3_2.*X_2.^3 + B4_2.*X_2.^4 + B5_2.*X_2.^5;
Nre_2= NP.^(1/6).*exp(Y_2);
Vf_2=va.*rhoa.*Nre_2./(rhoa.*2.*r0.*1e-6); %same conversion from Nre to Vf as before


vf_ind1=find(r0<535); vf_ind2=find(r0>=535);
Vf(vf_ind1)=Vf_1(vf_ind1); Vf(vf_ind2)=Vf_2(vf_ind2);

%final SSGF equation
pt1=((C1.*fs.*rhow.*ebar.*(r0.*1e-6).*WCC)./(sigma.*3)); % 1e-6 converts r0 from um to m to make units match
pt2=exp(((-3./2).*C2.*alpha).*(((pi.*etak)./(r0.*1e-6)).^(4/3)));
% pts 1 and 2 are the size distribution of droplets produced from TKE
pt3=0.5*(1+erf(((Uhrel-(Vf./(C3*MSS)))./(C4*sigmau))-C5)); 
% pt3 is the droplet ejection probability
Snr=(1e-6.*pt1.*pt2.*pt3)./rhow; % the SSGF is the product of the parts
% all units in m, 1e-6 converts r0 back to um for plot
% dividing by rhow converts mass to vol

% indx = find(r0>1 & r0<=500);
% snr(indx)=Snr(indx);
snr=Snr./2; % divide by 2 to center 30 m/s output on F94 graph

%--------------
function exx=bucksat(T,P,Tf)
% computes saturation vapor pressure [mb]
% given T [degC] and P [mb] Tf is freezing pt 
exx=6.1121.*exp(17.502.*T./(T+240.97)).*(1.0007+3.46e-6.*P);
ii=find(T<Tf);
exx(ii)=(1.0003+4.18e-6*P(ii)).*6.1115.*exp(22.452.*T(ii)./(T(ii)+272.55));%vapor pressure ice
end
%--------------------
function [q,em]=qsat26air(T,P,rh)
% computes saturation specific humidity [g/kg]
% given T [degC] and P [mb]
Tf=0;%assumes relative humidity for pure water
es=bucksat(T,P,Tf);
em=0.01*rh.*es; % in mb, partial pressure of water vapor
q=622*em./(P-0.378*em);
%--------------------------
end

end