function [vfa] = volfluxA98(r0,U10)
% Volume flux units are m3/(m2 s um)
% SSGF from Andreas (1989), no modifications

vfa=zeros(size(r0));
sphvol=((4*pi.*(r0.*1e-6).^3)/3); %scaling factor, in m

%constants
k=0.4; %von karman constant
Cdn10=(4.9e-4)+(6.5e-5)*U10; %m/s (dc should be dimensionless)
U14=U10.*(1+sqrt(Cdn10)/k.*log(14/10)); %m/s
A1=10.^(0.0676.*U14+2.43); %m/s
A2=10.^(0.959.*sqrt(U14)-1.476); %m/s
f1=3.1;
f2=3.3;
r1=2.1; %um
r2=9.2; %um
r80=0.518.*(r0.^(0.976)); %um

%base function
dfsdr80=(A1.*exp(-f1.*(log(r80./r1).^2)))+(A2.*exp(-f2.*(log(r80./r2).^2)));
dr80dr0=0.506.*r0.^(-0.024); 


dfmsdr0=3.5.*dfsdr80.*dr80dr0;
volflux0=sphvol.*dfmsdr0;

%calculating C1-3
%C1
dfdr80at10=(A1.*exp(-f1.*(log(10./r1).^2)))+(A2.*exp(-f2.*(log(10./r2).^2)));
C1=(dfdr80at10)./(U10.*10.^-1);
A=C1.*U10.*37.5.^(-1);
%C2
C2=A./(U10.*37.5^(-2.8));
B=C2.*(U10.*100^(-2.8));
%C3
C3=B./(U10.*100^(-8));
%A98 three component equations
A98C1=C1.*U10.*r80.^(-1); %from 10<=r80<=37.5 um. 
A98C2=C2.*U10.*r80.^(-2.8); %from 37.5<=r80<=100 um 
A98C3=C3.*U10.*r80.^(-8); %from 100<=r80<=250 um

%final subfunctions for each r0 range
volflux1=sphvol.*3.5.*A98C1.*dr80dr0; 
volflux2=sphvol.*3.5.*A98C2.*dr80dr0; 
volflux3=sphvol.*3.5.*A98C3.*dr80dr0;

% convert r80 limits into r0 limits
r80lim=[1 25 10 37.5 100 250];
r0lim=(r80lim/0.518).^(1/0.976);

%setting indices
ind0=find(r0>r0lim(1) & r0<=r0lim(3));
ind1=find(r0>r0lim(3) & r0<=r0lim(4));
ind2=find(r0>r0lim(4) & r0<=r0lim(5));
ind3=find(r0>r0lim(5) & r0<=r0lim(6));

%constraining ranges of each subfunction
vfa(ind0)=volflux0(ind0);
vfa(ind1)=volflux1(ind1);
vfa(ind2)=volflux2(ind2);
vfa(ind3)=volflux3(ind3);
end
