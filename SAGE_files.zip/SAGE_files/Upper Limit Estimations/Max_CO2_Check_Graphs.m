clear all; %close all
%% Calculating maximum possible spray-driven CO2 Efflux 
% Inputs- adjust as needed
TwC=2; %Sea Surface temp in C
TairC=5; %Air temp in C
dT = TairC -TwC;
RH = 65; % relative humidity

% Inputs- do not need to be adjusted
dr0=4;
r0=1:dr0:2000; %um
SAL=34; %Salinity
Pmpa=1000; % Atm pressure in MPa (Pa/1e6) 
P= 1000;        % Barometric Pressure (mb)

% CO2SYS inputs
PAR1TYPE = 4;         % Numerical indicator for the first input parameter
PAR2TYPE = 3;         % Numerical indicator for the second input parameter
PAR1 = 420;           % Value of the first parameter - due to the speed of gas exchange, the pCO2 within the droplet matches the air
PAR2 = 8.1;           % Value of the second parameter

[Max_CO2, WND_mx, WAGE_mx] = Max_CO2_Evasion_Check_B23WW3(r0,TwC,TairC,RH,SAL,P,PAR1TYPE,PAR2TYPE,PAR1,PAR2);
 
[Max_CO2_A98, WNDu] = Max_CO2_Evasion_Check_A98(r0,TwC,TairC,RH,SAL,P,PAR1TYPE,PAR2TYPE,PAR1,PAR2);

%% Literature Flux Calculations
MMG_CO2=44.01; % molecular mass of CO2 in g/mol
P= 1000;        % Barometric Pressure (mb)
RHOA=1.2922*(273.15/(273.15 + TairC))*(P/1013.25); % Air density kg/m³
Sc=2073.1-(125.62.*TwC)+(3.6276.*TwC.^2)-(0.043219.*TwC.^3); % T-dependent Sc number from Wan 1992
airCO2_ppm=420; % Keeling curve
SWCO2_ppm = 400;
dCO2_frac=(SWCO2_ppm-airCO2_ppm).*(1E-6); % fractional air-sea difference in pCO2

% (Nightingale et al 2000b)
N00_U10=0:16; % m/s
N00_K600=0.24.*(N00_U10.^2)+(0.061.*N00_U10); % cm/hr
N00_K660=((Sc./660).^-0.5).*(N00_K600./((Sc./600).^-0.5));
N00_FCO2=N00_K660./(100*60*60).*dCO2_frac; % m/s

% (McGillis et al 2001)
MG01_U10=0:20; % m/s
MG01_K660=3.3+0.026.*MG01_U10.^3; % cm/hr
MG01_FCO2=MG01_K660./(100*60*60).*dCO2_frac; % m/s

% (Ho et al 2006)
H06_U10=0.6:23.5; % m/s
H06_K600=0.266.*H06_U10.^2; % cm/hr
H06_K660=((Sc./660).^-0.5).*(H06_K600./((Sc./600).^-0.5));
H06_FCO2=H06_K660./(100*60*60).*dCO2_frac; % m/s

% (Wanninkhof et al 2014)
W14_K660 = 0.251.*MG01_U10.^2.*(Sc/660).^-0.5; % cm/hr
W14_FCO2=W14_K660./(100*60*60).*dCO2_frac; % m/s

%% Graphing Results

% figure
% % mx = scatter(WND,Max_CO2,500,WAGE,".");
%  mx = plot(WNDu,Max_CO2_A98,"-.");
% hold on
% mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
% w14=plot(MG01_U10,abs(W14_FCO2),"r-");
% n00=plot(N00_U10,abs(N00_FCO2),"b-");
% h06=plot(H06_U10,abs(H06_FCO2),"k--");
% % xlim([1 50])
% xlabel("Wind Speed (m/s)")
% ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
% title("Net CO2 Flux")
% legend([mx mg01 w14 n00 h06],"Max SAGE","MG01","W14","N00","H06")
% % set(gca, 'XScale', 'log')
% set(gca, 'YScale', 'log')
% 
% colormap("bone") % comment out to return to yellow/blue colors
% cc=colorbar;
% 
% caxis([15 47]);
% cc.Label.String='c_p/u_*';
% hold off
% 
% % savefig("MaxNetCO2Flux")
% 
% figure
% mx_a99 = scatter([11 12 13 14],Max_CO2_A99);
% hold on
% mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
% w14=plot(MG01_U10,abs(W14_FCO2),"r-");
% n00=plot(N00_U10,abs(N00_FCO2),"b-");
% h06=plot(H06_U10,abs(H06_FCO2),"k--");
% % xlim([1 50])
% xlabel("Wind Speed (m/s)")
% ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
% title("Net CO2 Flux")
% legend([mx_a99 mg01 w14 n00 h06],"Max A99","MG01","W14","N00","H06")
% % set(gca, 'XScale', 'log')
% set(gca, 'YScale', 'log')
% 
% % colormap("bone") % comment out to return to yellow/blue colors
% % cc=colorbar;
% % caxis([15 47]);
% % cc.Label.String='c_p/u_*';
% hold off
% 
% savefig("MaxNetCO2Flux_Ang99")
% 
% figure
% mx_a98 = plot(WNDu,Max_CO2_A98,":");
% hold on
% mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
% w14=plot(MG01_U10,abs(W14_FCO2),"r-");
% n00=plot(N00_U10,abs(N00_FCO2),"b-");
% h06=plot(H06_U10,abs(H06_FCO2),"k--");
% xlabel("Wind Speed (m/s)")
% ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
% title("Net CO2 Flux")
% legend([mx_a98 mg01 w14 n00 h06],"Max A98","MG01","W14","N00","H06")
% set(gca, 'YScale', 'log')
% hold off
% savefig("MaxNetCO2Flux_And98")

%% Load output .mats from sea spray flux model

% load prcsd_dT_0_results_RH_80_nonrctv.mat

%% Graphing SAGE output over max evasion
% % 
% figure
% % % Create First Axis
% ax1=axes;
% % mx = scatter(ax1,WND_mx,Max_CO2,500,WAGE_mx,".");
% mx_a98 = plot(WNDu,Max_CO2_A98,":");
% hold on
% mg01=plot(MG01_U10,abs(MG01_FCO2),"k-");
% w14=plot(MG01_U10,abs(W14_FCO2),"r-");
% n00=plot(N00_U10,abs(N00_FCO2),"b-");
% h06=plot(H06_U10,abs(H06_FCO2),"k--");
% 
% xlabel("Wind Speed (m/s)")
% ylabel("Net CO2 Flux (kg CO2/kg air * m/s)")
% title("Net CO2 Flux")
% % set(gca, 'XScale', 'log')
% set(gca, 'YScale', 'log')
% 
% % Create Second Axis 
% ax2=axes;
% b22=scatter(ax2,B22_U10pos,B22pos,50,WAGE_B22pos,'o',"filled");
% hold on
% scatter(ax2,B22_U10neg,abs(B22neg),50,WAGE_B22neg,'o')
% set(gca, 'YScale', 'log')
% 
% %%Link Axes
% linkaxes([ax1,ax2])
% %%Hide the top axes
% ax2.Visible = 'off';
% ax2.XTick = [];
% ax2.YTick = [];
% colormap(ax2,"jet") % comment out to return to yellow/blue colors
% cc=colorbar;
% caxis([0 48]);
% cc.Label.String='c_p/u_*';
% 
% 
% colormap(ax1,"bone") % comment out to return to Parula yellow/blue colors
% cc=colorbar;
% caxis([0 48]);
% cc.Label.String='c_p/u_*';
% 
% set([ax1,ax2],'Position',[.17 .11 .685 .815]);
% cb1 = colorbar(ax1,'Position',[.05 .11 .0675 .815]);
% cb2 = colorbar(ax2,'Position',[.88 .11 .0675 .815]);
% 
% 
% legend([b22 mx mg01 w14 n00 h06],"NonIdeal SAGE","Max SAGE","MG01","W14","N00","H06")
%% Save Results

filename = sprintf('max_CO2_chk_dT%d_RH%d_wave_ind.mat', dT, RH);
save(filename)

