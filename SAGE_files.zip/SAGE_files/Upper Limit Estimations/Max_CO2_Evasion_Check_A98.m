function [Max_CO2, WND]=Max_CO2_Evasion_Check_A98(r0,TwC,TairC,RH,SAL,P,PAR1TYPE,PAR2TYPE,PAR1,PAR2)

%% Maximum Possible CO2 Evasion from Sea Spray- Andreas 1989 SSGF

%% Inputs

% Molar mass of CO2, HCO3, CO3
MM_CO2 = 44.009; % g/mol
MM_HCO3 = 61.0168; % g/mol
MM_CO3 = 60.008; % g/mol

% Density of air %kg/m³
zt=1; % height of observation in m
T2K  = 273.16; % converts C to K
Tf=-0.0575*SAL+1.71052E-3*SAL.^1.5-2.154996E-4*SAL.*SAL; %freezing point of seawater
P_tq = P - (0.125*zt); % P at tq measurement height (mb)
[Q]  = qsat26air(TairC,P_tq,RH); % specific humidity of air (g/kg).
    % Assumes rh relative to ice T<0
    % Pv is the partial pressure due to water vapor in mb
Q=Q./1000;  % change Q to g/g
P_tq = P - (0.125*zt); % P at tq measurement height (mb)
Rgas = 287.1;
rhoa = P_tq*100./(Rgas*(TairC+T2K).*(1+0.61*Q));

% Density of seawater
rho0= 999.842594 + 6.793952e-2.*TwC - 9.095290e-3.*TwC.^2 + 1.001685e-4.*TwC.^3 - 1.120083e-6.*TwC.^4 + 6.536332e-9.*TwC.^5; % (kg m-3) 
A = 8.24493e-1 - 4.0899e-3.*TwC + 7.6438e-5.*TwC.^2  - 8.2467e-7.*TwC.^3 + 5.3875e-9.*TwC.^4;
B = -5.72466e-3 + 1.0227e-4.*TwC - 1.6546e-6.*TwC.^2;
C = 4.8314e-4;
rhow = A.*SAL + B.*SAL.^(3/2) + C.*SAL.^2 + rho0;

% CO2SYS Inputs------------------------------------------------------------
% nutrient data from OAZ data in Table 1 in Smith et al 2022
% Biogeochemical controls on ammonium accumulation in the surface layer of the Southern Ocean
% 
% SAL = S;              % Salinity 
TEMPIN = TwC;           % (degr. C) 
TEMPOUT = nan;        % (degr. C) 
PRESIN = 0;           % (dbar) 
PRESOUT = nan;        % (dbar) 
SI = 40.3;            % (umol/kgSW) 
PO4 = 2;              % (umol/kgSW) 
NH4 = 0.52;           % (umol/kgSW) 
H2S = 0;              % (umol/kgSW) 
pHSCALEIN =  1;       % (Total Scale)
K1K2CONSTANTS= 18;    % (Papadimitriou et al, 2018, T:-6 to 25 C S:35 to 100. Total scale. Real and artificial seawater.)
KSO4CONSTANT = 1;     % 1 = KSO4 of Dickson   (PREFERRED)
KFCONSTANT = 2;       % 2 = KF of Perez & Fraga, 1987  (PREFERRED)
BORON = 2;            % 2 = TB of Lee 2010  (PREFERRED)

% sea state data to run B22 SSGF
% 
g=9.8; %m/s^2, gravity

load all_data_mss.mat WND ; % loads WW3 data
WND = unique(WND);

%% Calculations

% Input inital seawater carbonate (pH, pCO2) conditions, get DIC,CO2/HCO3/CO3 split in ug/kg from CO2SYS

% Initial carbonate conditions snapshot------------------------------------

D = CO2SYS(PAR1,PAR2,PAR1TYPE,PAR2TYPE,SAL,TEMPIN,TEMPOUT,PRESIN,PRESOUT,SI,PO4,NH4,H2S,pHSCALEIN,K1K2CONSTANTS,KSO4CONSTANT,KFCONSTANT,BORON);
% runs CO2SYS for initial seawater conditions prior to temperature change
% or evaporation of droplet

% All units except pH and pCO2 are umol/kgSW
DIC = D(end,2);     % Extract new DIC value 
pH = D(end,3);      % Extract new pH value 
pCO2 = D(end,4);    % Extracts new pCO2 value 
HCO3 = D(end,6);      % Extract new HCO3 value 
CO3 = D(end,7);    % Extracts new CO32 value 
CO2 = D(end,8);     % Extracts new CO2 value 

% - Use stoichiometery to convert carbon species umol/kg SW to mol CO2/kg SW assuming total conversion.
% - Use water density to convert  mol CO2/kg SW to  mol CO2/L SW. 

CO2_molL = (CO2 + CO3 + HCO3)./1E6*rhow; % assume 1 mol of CO3/HCO3 converts to 1 mol of CO2

% - Using r0 vector, calculate initial droplet volume for each r0. 

vol_0 = (4/3).*pi.*(r0.^3); % um3
drop_vol = vol_0./((1E6)^3); % m3 or L

% - Multiply the mol/L max CO2 content times the volume per drop size (L) to get max mols CO2 released per drop size.

drop_maxCO2mol = CO2_molL.*drop_vol; % mols CO2 

% - Convert those units into kinematic mass flux by multiplying by CO2 molar mass, converting grams to kg, and dividing by the density of air. 

drop_maxCO2 = drop_maxCO2mol.*MM_CO2./1000./rhoa; % kg CO2/kg air m/s

% - Now run the SSGF for specific wave state- this will return the total volume of each droplet size class lifted. 
% - Divide by each droplet volume to get number of droplets of each size lifted. 

%Andreas 98
for n=1:length(WND)
    vra=volfluxA98(r0,WND(n));
    A98_numlift(:,n) = vra./drop_vol;
end

% - Multiply the number of drops of each size times the max carbon evasion of that droplet size to get net evasion due to droplets.

for  n=1:length(WND)

    Max_CO2_overdropsize(:,n) = drop_maxCO2'.*A98_numlift(:,n);

end

% -  Integrate over the droplet r0 vector to get a single value (kg CO2/kg air * m/s) that matches SAGE output units. 

for  n=1:length(WND)

    Max_CO2(n) = trapz(r0,Max_CO2_overdropsize(:,n));

end


%--------------
function exx=bucksat(T,P,Tf)
% computes saturation vapor pressure [mb]
% given T [degC] and P [mb] Tf is freezing pt 
exx=6.1121.*exp(17.502.*T./(T+240.97)).*(1.0007+3.46e-6.*P);
ii=find(T<Tf);
exx(ii)=(1.0003+4.18e-6*P(ii)).*6.1115.*exp(22.452.*T(ii)./(T(ii)+272.55));%vapor pressure ice
end
%--------------------
function [q,em]=qsat26air(T,P,rh)
% computes saturation specific humidity [g/kg]
% given T [degC] and P [mb]
Tf=0;%assumes relative humidity for pure water
es=bucksat(T,P,Tf);
em=0.01*rh.*es; % in mb, partial pressure of water vapor
q=622*em./(P-0.378*em);
%--------------------------
end

end