clear all; close all;

% this will take about 15 hours for a droplet size distribution of r0=10:4:2000 
% over 153 wave indices/sea state scenarios of 17 wind speeds with
% 8 wave ages each

%% SAGE Inputs

TwC = 2; TairC = -1; % set temperatures and differential
RelHum = [65, 80, 90]; % parallel computing for each RH scenario
DIC_initial = 2050; pH_initial = 8.1; % stable inital carbonate parameters
atmCO2_ppm = 410; seaCO2_ppm = 386;

% Wave Data
load all_data_mss.mat WND EDS FP HS MSS US WCC % includes mean squared wave slope and up to 50 m/s winds
g=9.8; %m/s^2, gravity
CP=g./(2*pi.*FP);% peak phase speed.
WAGE=CP./US; % compute wave age: cp/u*
WaveData=[WND WAGE CP EDS FP HS MSS US WCC];

% Wave Age Indices
winds = unique(WND); range = 5:100:805;
u_waveages=zeros(length(range),length(winds)); u_inds=zeros(length(range),length(winds));
for n=1:length(winds)
    u = find(WND==winds(n)); % lock in on one windspeed at a time
    u_subs = u(range); % start at the 5th and pull every 100th index
    u_waveages(:,n) = WAGE(u_subs); % pull those wave ages
    u_inds(:,n) = u_subs; % save wave age indices
end 
wave_ind = reshape(u_inds,[],1); % convert wave age indices from matrix to column vector

%% Parallel Computation of Multiple RHs (each serial looping over wave_ind)

% Start a parallel pool with 3 workers (one per RH)
if isempty(gcp('nocreate'))
    parpool(3);  % Adjust for fewer/more workers
end

% Submit each RH as a separate parallel task
futures = parallel.FevalFuture.empty(length(RelHum), 0);

for rh_idx = 1:length(RelHum)
    RH = RelHum(rh_idx);
    futures(rh_idx) = parfeval(@processRH, 0, wave_ind, RH);
    % Example: Add more arguments to parfeval
    futures(rh_idx) = parfeval(@processRH, 0, wave_ind, RH, TwC, TairC,...
        DIC_initial,pH_initial,HS,EDS,WND,FP,US,WCC,MSS,atmCO2_ppm,seaCO2_ppm);

end

% Wait for all futures to complete
wait(futures);

disp('All results saved.');

% ======= Worker Function =======
function processRH(wave_ind, RH, TwC, TairC,...
        DIC_initial,pH_initial,HS,EDS,WND,FP,US,WCC,MSS,atmCO2_ppm,seaCO2_ppm)

    tic;  % Start timing

    dT = TairC - TwC;

    for i = 1:length(wave_ind)

    [Evaporation_Parameters,Evolution_Results,Droplet_Net_KinFlux,SSGF_NetCO2Flux]=SAGE_NonIdeal_massbal_funct(RH,TwC,...
    TairC,DIC_initial,pH_initial,wave_ind(i),HS,EDS,WND,FP,US,WCC,MSS,atmCO2_ppm,seaCO2_ppm);

    % Store each iteration as a new row in a 2D matrix 
    SSGF_Outputs(i,:) = SSGF_NetCO2Flux;  % (153x6)
    
    % Store each iteration as a new row in a 2D matrix
    Evolution_Outputs(:,:,:,i) = Evolution_Results; % (146 x 16 x 498 x 53) 
    Droplet_Net_KinFlux_Outputs(:,:,i) = Droplet_Net_KinFlux;  % (498 x 4 x 153)
    Evaporation_Outputs(:,:,i) = Evaporation_Parameters;  % (498 x 4 x 153)

    end
    
    elapsedTime = toc;  % Stop timing

    filename = sprintf('dT_%g_results_RH_%g_4pH.mat',dT, RH);
    save(filename, 'SSGF_Outputs','Evolution_Outputs','Droplet_Net_KinFlux_Outputs',...
        'Evaporation_Outputs', 'RH', 'wave_ind', 'elapsedTime','dT','TwC',...
        'TairC','DIC_initial','pH_initial','atmCO2_ppm','seaCO2_ppm');
end
