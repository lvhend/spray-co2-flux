function t2=get_logarithmic_times(tmin,tmax,FAC)
%function get_logarithmic_times(tmin,tmax,FAC)
%
% get logarithmically spaced times between tmin and tmax
% FAC is the scaling increment such that tn= FAC tn-1
%
% FAC is generally 1.1 or smaller but greater than one.


%FAC= 1.1;

% tmin=0.01;
% tmax=10000;

t2(1)=tmin;
Nt=log(tmax/tmin)/log(FAC);

for n=2:Nt+2;
    t2(n)=t2(n-1)*FAC;

end

%max(t2)