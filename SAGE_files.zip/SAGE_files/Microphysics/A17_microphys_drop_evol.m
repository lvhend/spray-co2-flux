function [TEQ, TAU_T, r_EQ, TAU_R, SALEQ]=A17_microphys_drop_evol(r0,TwC,TairC,SAL,P,RH)

% === A17DropletEvolution.m === 
%adapted from Andreas, E. AN ALGORITHM FOR MAKING FAST CALCULATIONS OF 
%THE MICROPHYSICAL PROPERTIES OF EVOLVING SALINE DROPLETS. 2013. 
%PROGRAM ONE_FAST_MICRO_1.1 or EQUILB_1.1
%Available at: www.nwra.com/resumes/andreas/software.php

%% Variable Descriptions

% Input Variables
% r0= Initial Radius of the droplet in μm
% TwC= Water temperature in °C
% TairC=Air Temperature in °C
% RH= Relative humidity in %
% SAL=Salinity in psu
% P= Barometric Pressure in mb
% U10= Wind Speed in m/s

% Output Variables 
% TEQ -temperature at which the droplet begins to evaporate in °C 
% TAU_T -the time to reach TEQ in seconds
% r_EQ -the equilibrium radius in μm
% TAU_R -the time to reach equilibrium radius in seconds
% SALEQ, the salinity at radial equilibrium (psu)
% TAU_F, the droplet's estimated time aloft in seconds

%% Constants
TK=273.15; % Conversion constant from Celcius to Kelvin
CPW=4.0E3; % Specific heat of seawater in J/kg-K
MA=28.9644E-3; % Molecular weight of air in kg/mole
PI=3.141592; % Pi to six digits
RGAS=8.314417; % Universal gas constant in J/K/mol
MW=18.0150E-3; % Molecular weight of water in kg/mol
MS=58.443E-3; % Molecular weight of NaCl in kg/mol
P0=1013.25; % One atmosphere in MB

% IFLAG= determines whether saturation vapor pressure is calculated over water or ice 
% IFLAG can suppress a calculation of Saturation Vapor Pressure (mb) based on temperature.
        %		If IFLAG = 0, compute Saturation Vapor Pressure (mb) based on T.
        %		If IFLAG = 1, compute saturation over water.
        %		If IFLAG = 2, compute saturation over ice.

IFLAG=1; %models sea spray over water, make IFLAG an input value to allow calcuations over ice

%% Calculation of External Physical Conditions

F=0.01.*RH; %Fractional Relative humidity
TairK=TairC+TK; %Air Temp in Kelvins
TwK=TwC+TK; % Water temperature in Kelvins

R0=r0.*(10.^-6); %Initial droplet radius in meters

% === AIR DENSITY ===
% P= Barometric Pressure in mb, T is in K
RHOA=1.2922.*(TK/(TK + TairC)).*(P./1013.25);

% === WATER DENSITY ===
% (density of pure water at TwC- change eq to account for salinity, recalculate in evaporation equilibration)
if TwC<0
  RHOW = 999.84 + TwC.*(8.60E-2 - 1.08E-2.*TwC);
else
 RHOW=(999.8396+TwC.*(18.224944-7.922210E-3.*TwC))/(1+1.8159725E-2.*TwC);
end

% === SPECIFIC HEAT OF DRY AIR  ===
% for air temperature T in degrees C between -40 and +40 C
% Units: J/kg/K
SPEC_HT_AIR = 1005.60 + TairC.*(0.017211 + 0.000392.*TairC);

%% Thermal Equilibration

% Estimates the temperature at which sea spray droplets are thermally
% equilibrated with the atmosphere.

%------------------------ KEPERT'S SUBROUTINE --------------------------------------

    %  This subroutine implements Andreas' modification of Jeff Kepert's (1996)
    %  algorithm for estimating the temperature at which sea spray droplets evaporate.
    %  Kepert evaluated temperature derivatives of saturation vapor pressure
    %  from the Clausius-Clapeyron equation. A straightforward differentiation 
    %  of Buck's (1981) equation.
    
    %  SOME VARIABLE DEFINITIONS
    %  R0 is the droplet radius in meters.
    %  S is the fractional salinity.
    %  TairK is the air temperature in kelvins 
    %  F is the fractional relative humidity.
    %  P is barometric pressure.
    %  T_EQ is the estimated evaporating temperature.
     
    % Constants in Buck's (1981) equation for saturation vapor pressure
    AA=17.502;
    BB=240.97;
    
%************************* SATURATION VAPOR PRESSURE **********************************
       
        %This subroutine uses Buck's (1981) equation to find the saturation vapor
        %  pressure as temperature T and atmospheric pressure P.  The equation is
        %
        %		E = (PA*P + PB)*E0*EXP((A*T)/(B + T)
        %
        %  where P and E are in mb, and T is in degrees C.

        %  IFLAG can suppress a calculation of E based on temperature.
        %		If IFLAG = 0, compute E based on T.
        %		If IFLAG = 1, compute saturation over water.
        %		If IFLAG = 2, compute saturation over ice.
        
                
        % Coefficients in saturation vapor pressure equation
        PA=[3.46E-6 4.18E-6]; 
        PB=[1.0007 1.0003];
        E0=[6.1121 6.1115];
        A=[17.502 22.452]; 
        B=[240.97 272.55];
        
        % K indexes which value for each coefficient to use to calculate
        % saturation vapor pressure depending if the spray is over 
        % ice or water
        K = 1; % default is over water
        
        if IFLAG==0  % compute Saturation Vapor Pressure (mb) based on T
            if T<0
                K=2;
                
            end
             % Saturation Vapor Pressure (mb)
            ESAT = (PA(K)*P + PB(K))*E0(K)*exp((A(K)*TairC)/(B(K) + TairC));
         
        elseif IFLAG==1 % compute saturation vapor pressure over water
             % Saturation Vapor Pressure (mb)
            ESAT = (PA(K)*P + PB(K))*E0(K)*exp((A(K)*TairC)/(B(K) + TairC));

        elseif IFLAG==2 % compute saturation vapor pressure over ice
            K=2;
            % Saturation Vapor Pressure (mb)
            ESAT = (PA(K)*P + PB(K))*E0(K)*exp((A(K)*TairC)/(B(K) + TairC));
        else
            % Error handling
            error('IFLAG is outside the range of acceptable values. We Quit.')
            %return;
        end
       
%**************************************************************************

%************************* SPRAY CONSTANTS **********************************  
                
        % This section computes constants that are used in various
        % microphysical computations involving spray.
        % R0 is the droplet radius in meters.
        % TairK is the air temperature in kelvins 
        % TwK is the water temperature in kelvins 
        % P is the barometric pressure in mb.
        % MASSS is the mass of salt in the droplet.
        % MSMW is the ratio of salt to water mass prior to evaporation
               
        
        NI=2; % Number of ions in NaCL
        S=0.001.*SAL; %Fractional Salinity
        MSMW=S./(1-S); % Mass of salt/mass of water
        MASSS=1000.0.*1.333333.*PI.*(R0.^3).*MSMW; % Mass of salt in droplet
        MASSW=MASSS/MSMW; % Mass of pure water in droplet

            % Latent heat of vaporization or sublimation of water (J/kg)
            % dependent on if the droplet is over ice or water
    
            if IFLAG==0 % calculate based on T
                if TwC<0
                    LV=(28.34 - 0.00149*TwC)*1.0E+5;
                else
                    LV=(25.00 - 0.02274*TwC)*1.0E+5;
                end
            elseif IFLAG==1 % over water
                LV=(25.00 - 0.02274*TwC)*1.0E+5;
            elseif IFLAG==2 % over ice
                LV=(28.34 - 0.00149*TwC)*1.0E+5;
            else
                error('Bad IFLAG')
            end
    
            % Surface tension of droplet.
            %  This function computes the surface tension of a liquid-water/air interface
            %  for temperatures between -45 and +40 deg C.  The water may be saline.
            %  The approach is based on equations given in Andreas (2005, CRREL Monograph M-05-1).
            %  T is the water temperature in degrees Celsius.
            %  MSMW is the ratio of the mass of salt to the mass of pure water in the sample.
            %  Units of TENSN are J/m**2.
        
            if TwC<-45
                error('Temperature too low for calculating surface tension')
            elseif TwC<0
                TENSION_WATER=(7.593E-2)+TwC*((1.15E-4)+TwC*((6.818E-5)+TwC*...
                    ((6.511E-6)+TwC*((2.933E-7)+TwC*((6.283E-9)+(5.285E-11)*TwC)))));
            elseif TwC<40
                TENSION_WATER=0.2358*(((374.0-TwC)/647.15)^1.256)*(1-0.625*((374.0-TwC)/647.15));
            else
                error('Temperature too high for calculating surface tension.')
            end 
                TENSN=TENSION_WATER+(2.77E-2)*MSMW;
                SIGMA=TENSN;


%>>>>>>>>>>>>>>>>> THERMAL CONDUCTIVITY AND MOLECULAR DIFFUSIVITY >>>>>>>>>>
                        
            % This subroutine computes the thermal conductivity of air, KAP, and
            % the molecular diffusivity of water vapor in air, DWP, adjusted for non-continuum effects. 
            % R0 is the droplet radius in m.
            % TwK is the droplet temperature in Kelvins.
            % P is the atmospheric pressure in mb.

            % Normal thermal conductivity
            KA=(2.411E-2)*(1+TwC*((3.309E-3)-(1.441E-6)*TwC)); % why do we use water T to calculate conductivity of air?
            
            % Length scales in m
            DELT=2.16E-7;
            DELW=8.0E-8;
            % Dimensionless constants
            ALPHAC=0.036;
            ALPHAT=0.7;
            
            % Bulk molecular diffusivity
            DW = (2.11E-5)*((TwK/TK)^1.94)*(P0/P);
            % Calculation factors
            FAC1=sqrt((2*PI)/(RGAS*TwK)); %for the gas pressure in the droplet
            FACK=(sqrt(MA)*FAC1*KA)./(R0*ALPHAT*RHOA*SPEC_HT_AIR); %for the ambient air
            % Thermal conductivity of air
            KAP=KA./((R0./(R0+DELT))+ FACK);
            % Calculation factor
            FACD=(sqrt(MW)*FAC1*DW)./(R0*ALPHAC);
            % Molecular diffusivity of water vapor in air
            DWP=DW./((R0./(R0+DELW))+FACD);

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        % Molality of salt before evaporation begins
        CURLYM=MSMW./MS;
        % Practical osmotic coefficient before evaporation begins
        PHIS=0.92701+CURLYM*(-2.1637E-2+CURLYM*(3.4855E-2+ CURLYM*(-5.9560E-3 + 3.9112E-4*CURLYM)));

%**************************************************************************

    % Y is a function described in Andreas 1989 that gives the effects
    % of droplet curvature and dissolved salt on the vapor pressure at
    % the surface of a spray droplet. 
        
    % Terms in Y 
       
    YTERM1=(2*MW*SIGMA)./(RGAS*TairK*RHOW);  % Term related to curvature effect
    YFAC1=YTERM1./R0; 

    YTERM2=NI*PHIS*MASSS*(MW/MS); % Term related to salinity effect
    YFAC2=YTERM2./MASSW; 
        
    % Messy nondimensional function Y
    Y=YFAC1 - YFAC2;
    
    % Base e exponent of Y (curvature &salinity effects)
    EY=exp(Y);
   
    % Alpha from Andreas (Literature)
    MY_ALPHA=(AA*BB*TairK)/((BB + TairC)^2);   % what terms are these?
    % Kepert's Alpha (literature)
    ALPHA=(MW*LV)/(RGAS*TairK);
    % Keperts beta (literature)
    BETA=ALPHA*(100*ESAT*DWP)/KAP;

    % SKA/B/C are quadratic equation
    SKA=(BETA/(TairK^2))*(0.5*(MY_ALPHA^2)-MY_ALPHA*((2*TairC+BB+TK)/(BB+TairC))+1.0)*EY;
    SKB=1.0+(BETA/TairK)*(MY_ALPHA-1.0)*EY;
    SKC=-BETA*(F-EY);
    %Changed A, B and C to SKA, SKB and SKC

    % How much the temperature will change  before evaporation (in C)
    DELTAT=(-SKB+(sqrt((SKB.^2)-4.0.*SKA.*SKC)))./(2.*SKA); %changed to reflect actual quadratic equation and changed SKB- to SKB+
    
    % Estimated evaporating temperature 
    TEQ=DELTAT + TairC; % estimated equilibrium temperature in C

%--------------------------------------------------------------------------

%-------------- SATURATION VAPOR PRESSURE AT THERMAL EQUILIBRIUM-----------

% Buck's (1981) equation to find the saturation vapor pressure after
% thermal equilibration
      
        %This subroutine uses Buck's (1981) equation to find the saturation vapor
        %  pressure as temperature T and atmospheric pressure P.  The equation is
        %
        %		E = (PA*P + PB)*E0*EXP((A*T)/(B + T)
        %
        %  where P and E are in mb, and T is in degrees C.
        %  IFLAG can suppress a calculation of E based on temperature.
        %		If IFLAG = 0, compute E based on T.
        %		If IFLAG = 1, compute saturation over water.
        %		If IFLAG = 2, compute saturation over ice.
        
        % Coefficients in saturation vapor pressure equation
        PA1=[3.46E-6 4.18E-6]; 
        PB1=[1.0007 1.0003];
        E01=[6.1121 6.1115];
        A1=[17.502 22.452]; 
        B1=[240.97 272.55];
        
        % K indexes which value for each coefficient to use to calculate
        % saturation vapor pressure depending if the spray is over 
        % ice or water
        K1 = 1; % default is over water
        
       if IFLAG==0 % compute Saturation Vapor Pressure (mb) based on T
            if TEQ<0
                K1=2;
                
            end
                ESATTA = (PA1(K1)*P + PB1(K1))*E01(K1)*exp((A1(K1)*TEQ)/(B1(K1) + TEQ));
         
        elseif IFLAG==1 % compute saturation vapor pressure over water
             % Saturation Vapor Pressure (mb)
            ESATTA = (PA1(K1)*P + PB1(K1))*E01(K1)*exp((A1(K1)*TEQ)/(B1(K1) + TEQ));
        elseif IFLAG==2 % compute saturation vapor pressure over ice
            K1=2;
            % Saturation Vapor Pressure (mb)
            ESATTA = (PA1(K1)*P + PB1(K1))*E01(K1)*exp((A1(K1)*TEQ)/(B1(K1) + TEQ));
        else
            % Error handling
            error('IFLAG is outside the range of acceptable values. We Quit.')
            %return;
        end
       
%--------------------------------------------------------------------------

% Saturation vapor density after thermal equilibration
RHOV_SAT=(100.0*MW*ESATTA)/(RGAS*TairK);

% Derivative of saturation vapor density after thermal equilibration with respect to changing T
DRHOV_DT=RHOV_SAT*((AA*BB)/((BB+TairC)^2)-1.0/TairK); %not sure why this eq has temperature in units of both C and K

%>>>>>>>>>>> SOLUTION MASS AND DENSITY AFTER THERMAL EQUILIBRATION >>>>>>>>
   
        %  This subroutine computes the density (RHOSOL) and mass (MASSD) of
        %  an aqueous solution droplet for which the salt to pure water mass
        %  ratio (MASSS/MASSW) is MSMW.  The equation for RHOSOL is from 
        % PRUPPACHER AND KLETT (1978, P. 87).

        %  R0 is the droplet radius (in m) 
        %  TEQ is the water temperature   
        %  MS is the molecular weight of NaCl. 
        %  VA is the apparant molal volume of salt
        %  RHOW_THEQ is the density of pure water at TEQ
       
        
        % Volume of droplet (m3)
        VOL=1.333333.*PI.*(R0.^3);
        % Molarity of salt
        CONC=(MASSS./MS)./VOL;

        % These terms include the equilibration temperature 
        % Apparent molal volume at infinite dilution
        VA0=12.97+TEQ.*(0.2340+TEQ.*(-4.210E-3+2.857E-5.*TEQ));
        % Slope parameter
        SVSTAR=2.982+TEQ.*(-4.790E-2+6.032E-4.*TEQ);
        % Apparent molal volume
        VA=(VA0+SVSTAR.*sqrt(1.0E-3.*CONC)).*1.0E-6;

        % Solution density after thermal equilibration
        RHOSOL=RHOW.*(1+MSMW)./(1+(VA.*RHOW.*MSMW)./MS);
%         % Droplet mass
%         MASSD_THEQ=RHOSOL+THEQ.*VOL;


% The salt concentrations, water to salt ratios, and water mass
% calculations here all describe the droplet before any evaporation has
% occurred. 
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


% Time required for the temperature change
TAU_T=((R0.^2).*RHOSOL.*CPW)./(3.0.*(KAP+LV.*DWP.*DRHOV_DT)); % should this be eq dens or init dens


%% Radial Equilibration

% the evaporation of the droplet at constant temperature TEQ
TINF=TairK; % TINF is the variable name used in AGES as published

% Air density (kg/m3) (why is this here? and using water T to calcualate
% air density?)
RHOA_EQ=1.2922.*(TK./(TK+TEQ)).*(P./1013.25);

% Mass of water in droplet after thermal equilibration but before
% evaporation
MASSW=(4.0./3.0).*PI.*(R0.^3).*RHOSOL-MASSS;

% Thermal conductivity of air in W/kg-K
KA=0.02411.*(1.0+TEQ.*((3.309E-3)-(1.441E-6).*TEQ));

% Vapor diffusivity (m2/s)
DW=2.11E-5.*(((TK+TEQ)./TK).^1.94).*(1013.25./P);

% Term's 1-6 are set up for TAU_R
TERM1=(RHOSOL.*RGAS.*TINF)./(MW.*100.0.*ESATTA);
TERM2=(LV.*RHOSOL./TINF).*((LV.*MW)./(RGAS.*TINF) - 1.0);
TERM3=YTERM1;
TERM4=YTERM2;
TERM5=sqrt((2.*PI.*MW)./(RGAS.*TINF))./0.036;
TERM6=sqrt((2.*PI.*MA)./(RGAS.*TINF))./(0.7.*RHOA_EQ.*SPEC_HT_AIR);

% Derivative of r with respect to time
DR_DT=((F -1.0)-Y)./(R0.*(TERM1./DWP+TERM2./KAP));

% Derivative of y with respect to r
DY_DR=-TERM3./(R0.^2)+(TERM4./(MASSW.^2)).*(4.0.*PI.*RHOSOL.*(R0.^2));

% DENOM and DENOM1/2A/2B/2C/3 are computation 
% for second derivative of r
DENOM1=1./R0+DY_DR./((F-1.0)-Y);
DENOM2A=((TERM1.*TERM5)+(TERM2.*TERM6))/(R0.^2);
DENOM2B=-(TERM1./DW).*(8E-8./((R0+(8E-8)).^2));
DENOM2C=-(TERM2./KA).*((2.16E-7)./((R0+(2.16E-7)).^2));
DENOM3=-(TERM1./DWP+TERM2./KAP);
DENOM=DENOM1+(DENOM2A+DENOM2B+DENOM2C)./DENOM3;

% 2nd derivative of r with respect to time
D2R_DT2=-(DR_DT.^2).*DENOM;

% Script for Newton's method to estimate the equilibrium radius (REQ) of a droplet
%EST_REQ;
    % Criterion for convergence of radius estimate
    RADCON=0.001;
    
    TEQK=TEQ+TK	;				% Droplet temperature in kelvins %
    MASSS0=MASSS;					% Save mass of salt %
    
    % Factors for subsequent calculations
    FAC1=(4.0/3.0)*PI;
    FAC2=4.0*PI;
    
    KOUNT=0;						% Iteration count
    REQ=R0;						% First estimate of REQ
    
    % Ratio of dry salt particle
    REQ_MIN=(MASSS0/(FAC1*RHOSOL))^(1.0/3.0);
    
    % Mass of pure water in droplet
    MASSW=FAC1.*RHOSOL.*(REQ.^3)-MASSS0;
    
    % Mass of salt/mass of water
    MSMW=MASSS0/MASSW;
    
    % SOLUTN.m Script
    %SOLUTN;
        Twater=TwC;
        R=R0;
        % Defining RHOW (density of pure water at TW)
        if TwC<0
            RHOW = 999.84 + Twater*(8.60E-2 - 1.08E-2*Twater);
        else
            RHOW=(999.8396+Twater*(18.224944-7.922210E-3*Twater))/(1+1.8159725E-2*Twater);
        end
        
        
        % Volume of droplet (m3)
        VOL=1.333333.*PI.*(R.^3);
        % Molarity of salt
        CONC=(MASSS./MS)./VOL;
        % Apparent molal volume at infinite dilution
        VA0=12.97+Twater*(0.2340+Twater*(-4.210E-3+2.857E-5*Twater));
        % Slope parameter
        SVSTAR=2.982+Twater*(-4.790E-2+6.032E-4*Twater);
        % Apparent molal volume
        VA=(VA0+SVSTAR*sqrt(1.0E-3*CONC))*1.0E-6;
        % Solution density
        RHOSOL=RHOW.*(1+MSMW)./(1+(VA.*RHOW.*MSMW)./MS);
        % Droplet mass
        MASSD=RHOSOL.*VOL;
    
    % Iteration count
    KOUNT=0;
    
    % Save previous value of REQ as it loops
    REQ_OLD=0;
    
    
    while abs((REQ-REQ_OLD)/REQ_OLD)>RADCON
        
        REQ_OLD=REQ;
        
        % Mass of salt/mass of water
        MASSW=FAC1.*RHOSOL.*(REQ.^3)-MASSS0;
        if MASSW<0
            error('Mass of water droplet less than zero')
        else
            % quantifies the curvature and 
            % salinity effects on a droplets 
            % vapor pressure
            Y=(YTERM1./REQ)-(YTERM2./MASSW);
        end
        
        % function to zero
        G=(F - 1.0)-Y;
        G1=YTERM1./(REQ.^2);
        G2=-(YTERM2.*(FAC2.*RHOSOL.*(REQ.^2))./(MASSW.^2));
        
        % Derivative of G
        DG_DR=G1+G2;
        REQ=REQ-(G./DG_DR);
        if REQ<(0.5.*REQ_OLD)
            REQ=0.5.*REQ_OLD;
        end
        KOUNT=KOUNT+1;
        if KOUNT>20
            error ('EST_REQ KOUNT is Greater than 20')
        end
        
    end
    % Add a while statement with KOUNT<20, return spits it back out to keep running the program remember to terminat while loop
    MSMW = MASSS0./MASSW;
    
    % SOLUTN.m script
    %SOLUTN;

        % Defining RHOW (density of pure water at TW)
        if TwC<0
            RHOW = 999.84 + Twater*(8.60E-2 - 1.08E-2*Twater);
        else
            RHOW=(999.8396+Twater*(18.224944-7.922210E-3*Twater))/(1+1.8159725E-2*Twater);
        end
        
        
        % Volume of droplet (m3)
        VOL=1.333333.*PI.*(R.^3);
        % Molarity of salt
        CONC=(MASSS./MS)./VOL;
        % Apparent molal volume at infinite dilution
        VA0=12.97+Twater*(0.2340+Twater*(-4.210E-3+2.857E-5*Twater));
        % Slope parameter
        SVSTAR=2.982+Twater*(-4.790E-2+6.032E-4*Twater);
        % Apparent molal volume
        VA=(VA0+SVSTAR*sqrt(1.0E-3*CONC))*1.0E-6;
        % Solution density
        RHOSOL=RHOW.*(1+MSMW)./(1+(VA.*RHOW.*MSMW)./MS);
        % Droplet mass
        MASSD=RHOSOL.*VOL;
    
    % SPRAY_CONSTANTS_2.m script
    %SPRAY_CONSTANTS_2;
        % Number of ions in NaCL
        NI=2;

        TW=TwK;
        % Water temp in C
        TWC=TW-TK;
        % Mass of pure water in droplet
        MASSW=MASSS./MSMW;


        % Latent heat of vaporization of water (J/kg)
        % Latent function from LATENT.m
        %LV=LATENT(TWC,IFLAG);
            if IFLAG==0
                if T<0
                    LV=(28.34 - 0.00149*TwC)*1.0E+5;
                else
                    LV=(25.00 - 0.02274*TwC)*1.0E+5;
                end
            elseif IFLAG==1
                LV=(25.00 - 0.02274*TwC)*1.0E+5;
            elseif IFLAG==2
                LV=(28.34 - 0.00149*TwC)*1.0E+5;
            else
                error('Bad IFLAG')
            end

        % KAPDWP.m script.
        %KAPDWP;
            % === KAPDWP.m ===
            
            % THIS SUBROUTINE COMPUTES THE THERMAL CONDUCTIVITY OF AIR, KAP, AND
            % THE MOLECULAR DIFFUSIVITY OF WATER VAPOR IN AIR, DWP, ADJUSTED FOR
            % NON-CONTINUUM EFFECTS.
            % R IS THE DROPLET RADIUS IN M.
            % TW IS THE DROPLET TEMPERATURE IN KELVINS.
            % P IS THE ATMOSPHERIC PRESSURE IN MB.
            %adapted from Andreas, E. AN ALGORITHM FOR MAKING FAST CALCULATIONS OF 
            %THE MICROPHYSICAL PROPERTIES OF EVOLVING SALINE DROPLETS. 2013. 
            %PROGRAM ONE_FAST_MICRO_1.1 or EQUILB_1.1
            %Available at: www.nwra.com/resumes/andreas/software.php


            % Droplet temperature in C
            TWC=TW-TK;
            % Normal thermal conductivity
            KA=(2.411E-2)*(1+TWC*((3.309E-3)-(1.441E-6)*TWC));
            % Air density (kg/m3)
            RHOA=1.2922*(TK/TW)*(P/P0);
            % Bulk molecular diffusivity
            DW = (2.11E-5)*((TW/TK)^1.94)*(P0/P);
            % Calculation factors
            FAC1=sqrt((2*PI)/(RGAS*TW));
            FACK=(sqrt(MA).*FAC1.*KA)./(R.*ALPHAT.*RHOA.*SPEC_HT_AIR);
            % Thermal conductivity of air
            KAP=KA./((R./(R+DELT))+ FACK);
            % Calculation factor
            FACD=(sqrt(MW).*FAC1.*DW)./(R.*ALPHAC);
            % Molecular diffusivity of water vapor in air
            DWP=DW./((R./(R+DELW))+FACD);

        % Surface tension
        %SIGMA=TENSN(TWC,MSMW);
            if TwC<-45
                error('Temperature too low for calculating surface tension')
            elseif TwC<0
                TENSION_WATER=(7.593E-2)+TwC*((1.15E-4)+TwC*((6.818E-5)+TwC*((6.511E-6)+TwC*((2.933E-7)+TwC*((6.283E-9)+(5.285E-11)*TwC)))));
            elseif TwC<40
                TENSION_WATER=0.2358*(((374.0-TwC)/647.15)^1.256)*(1-0.625*((374.0-TwC)/647.15));
            else
                error('Temperature too high for calculating surface tension.')
            end 
                TENSN=TENSION_WATER+(2.77E-2)*MSMW;
                SIGMA=TENSN;


        % Molality
        CURLYM=MSMW/MS;
        % Practical osmotic coefficient
        PHIS=0.92701+CURLYM.*(-2.1637E-2+CURLYM.*(3.4855E-2+ CURLYM.*(-5.9560E-3 + 3.9112E-4.*CURLYM)));
        % Related to curvature effect
        YTERM1=(2.*MW.*SIGMA)./(RGAS.*TINF.*RHOW);%changed TINF to Tair
        % Related to salinity effect
        YTERM2=NI.*PHIS.*MASSS.*(MW./MS);
        % Terms in Y
        YFAC1=YTERM1./R;
        YFAC2=YTERM2./MASSW;
        % Messy nondimensional function
        Y=YFAC1 - YFAC2;


% Change in R due to evaporation, used to estimate TAU_R
RDIF=R0-REQ;

% Used to estimate TAU_R
XINSQRT=3.0.*(DR_DT.^2)-2.0.*RDIF.*D2R_DT2;
if XINSQRT<0;
    % Both HUM_FAC and TAU_R01 are used to 
    % estimate TAU_R in high humidities
    HUM_FAC=-9.4013E2 + F.*(1.93607E3 - 9.955E2.*F); % humidity factor
    TAU_R01=-RDIF./DR_DT;
    
    % Time for radius to reach equilibrium
    TAU_R=TAU_R01./HUM_FAC;
else
    % Both TS_NUM1 and TS_DENOM
    % are used to estimate TAU_R
    TS_NUM1=sqrt(XINSQRT);
	TS_DENOM=D2R_DT2-((DR_DT.^2)./RDIF);
    
    % Time for radius to reach equilibrium
	TAU_R=(-DR_DT-TS_NUM1)./TS_DENOM;
end

% Script to calculate the equilibrium salinity
% === SALINITY.m ===

% Calculates the equilibrium salinity by calculating the equilibrium volume
% of the droplet(m^3) and multiplying that by the density of pure water at
% TW(double check validity of thisaka RHOW) then taking the salt and putting it in
% the droplet in kg salt per kg water


% VOLEQ is the equilibrium volume (m3)
% REQ is defined in EST_REQ.m
VOLEQ=1.333333.*PI.*(REQ.^3);
% KGW is the mass of water in equilibrated droplets
% RHOW is defined in SOLUTN.m
KGW=VOLEQ.*RHOW;
% SALEQ is the salt in the equilibrated 
% droplet in g_salt/kg_water (approximates psu)
% MASSS is defined in SPRAY_CONSTANTS.m
SALEQ=(MASSS.*1000)./KGW;

% Equilibrium radius
% Convert the equilibrium radius to um
r_EQ = REQ.* (1e6);

end