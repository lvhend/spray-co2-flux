function [U10_TAU_F] = TAU_F_WND_ONLY(r0,U10,TairC,TwC,P)

% DROPLET_TIME_ALOFT 
% [TAU_F] = TAU_F_Vd(r0,WND,HS,US,TairC,TwC,P)
G=9.80; % Gravity constant for Earth (m/s2)
NU=1.46e-5; %m2/s   %kinematic viscosity of air at 20C

% Air density
RHOA=1.2922*(273.15/(273.15 + TairC))*(P/1013.25); %kg/m³
% RHOA=1.2041; %kg/m³    %density of air at 20C, reference value

% Density of seawater (kg/m3) 
        if TwC<0
          RHOW = 999.84 + TwC.*(8.60E-2 - 1.08E-2.*TwC);
        else
         RHOW=(999.8396+TwC.*(18.224944-7.922210E-3.*TwC))/(1+1.8159725E-2.*TwC);
        end
% RHOW=1025; %kg/m³   %seawater density at seawater cond of 20C and 35S

% COARE equation for Stokes fall speed in m/s (Fairall 2003)

STOKES=1e-30.*ones(size(r0)); 
for n=1:100
    STOKES=(((2.*G.*((r0.*1e-6).^2))./(9.*NU.*(1+0.158.*(2.*(r0.*1e-6).*STOKES./NU).^(2/3)))).*((RHOW./RHOA)-1));    
end

% Particle deposition velocity from Smith, M. H., P. M. Park, and I. E. Consterdine (1993), 
% Marine aerosol concentrations and estimated fluxes over the sea. Q. J. R. Meteorol. Soc., 119(512), 809–824.

% CD=(US./WND).^2;  % COARE drag coefficient calculation

% Vd=STOKES./(1-exp(-(STOKES./CD.*WND))); % Particle deposition velocity in m/s

% TAU_F=2.*HS./Vd; % Time aloft in seconds
As=(0.015.*(U10.^2)); % Wave amplitude as a function of wind speed, replace w WW3 data
U10_TAU_F=As./STOKES;   
 %Calculating TAU_F, time aloft in seconds. 


%%

 % Andreas 1989 calculated TAU_F as 1/fallspeed but this would have units of s/m. Multiplying it by wave
 % amplitude in meters gives seconds (Andreas et al., 1995; Edson et al., 1996; and Van Eijk et al., 2001)
 % It is assumed that including U10 in the calculations includes the effect of turbulence. 
 % The relationship between As and U10 is from (Kinsman, 1965; Wilson, 1965; Earle, 1979
  
end

