function [t,r,S,T,VOL,r_EQ,TAU_F, U10_TAU_F,pCO2_droplet,fCO2_corrected,...
    CO2_Flux_Evol_umol,KinCO2Flux_alft,KinCO2Flux_u10_alft,...
    kd_660_evol,kd_660,kd_660_u10,KH] = nonrctv_CO2_flux_drop(r0,TwC,TairC,...
    RH,SAL,P,wave_ind,HS,WND,US,atmCO2_ppm,seaCO2_ppm)

%% Andreas Microphysical Model Calculations

% Input Variables w example values

% r0 = Initial radius of the droplet (μm)
% TwC = Water temperature (°C)
% TairC = Air Temperature (°C)
% RH = Relative humidity in %
% pH_initial = Initial pH
% DIC_initial = Initial DIC value
% SAL = Salinity 
% P = Barometric Pressure (mb)
% seaCO2_ppm = 386; % Pulled from https://explore.webodv.awi.de/ocean/carbon/socat/socatv2024/
% atmCO2_ppm = 410; % Pulled from Keeling Curve

% calcualate timesteps
t = get_logarithmic_times(0.01,10000,1.1); % time of droplet evolution in seconds, spaced logarithmically

% Running the microphysical model

[TEQ, TAU_T, r_EQ, TAU_R, SALEQ] = A17_microphys_drop_evol(r0,TwC,TairC,SAL,P,RH);

% Calculating microphysical evolution curves from final and initial model conditions

T =  TEQ + exp(-t./TAU_T).*(TwC - TEQ);           % Thermal evolution curve (C)
r = r_EQ + exp(-t./TAU_R).*(r0 - r_EQ);           % Radial evolution curve (um)
S =  SAL+(1- exp(-t./TAU_R)).*(SALEQ - SAL);      % Salinity evolution curve (psu)
VOL = (4/3).*pi.*(r.^3);                          % Volume evolution curve in um^3, assumes perfect sphere
VOL_m3 = VOL .* ((1e-6).^3);                      % Volume evolution curve in m^3

t=t';r=r';S=S';T=T'; % transposes microphysical parameters from row to col vector for function output

rhow = zeros(1,length(t));
% Density of seawater %kg/m³
for n = 1:length(t)
    rho0= 999.842594 + 6.793952e-2.*T(n) - 9.095290e-3.*T(n).^2 + 1.001685e-4.*T(n).^3 - 1.120083e-6.*T(n).^4 + 6.536332e-9.*T(n).^5; % (kg m-3) 
    A = 8.24493e-1 - 4.0899e-3.*T(n) + 7.6438e-5.*T(n).^2  - 8.2467e-7.*T(n).^3 + 5.3875e-9.*T(n).^4;
    B = -5.72466e-3 + 1.0227e-4.*(n) - 1.6546e-6.*T(n).^2;
    C = 4.8314e-4;
    rhow(n) = A.*S(n) + B.*S(n).^(3/2) + C.*S(n).^2 + rho0;
end

MASS_kg = VOL_m3 .* rhow; % kg of seawater in the droplet

%% CO2 Gas Concentration from Henry's Constant Under Changing Temperature and Salinity

% This section computes Henry's Constant for CO2 using the Weiss 1974 eq 12:

% Weiss Table 1 Constants for Eq 12 (below) in units of mol/L/atm
A1w = -58.0931; A2w = 90.5069; A3w = 22.2940; 
B1w = 0.027766; B2w = -0.025888; B3w = 0.0050578;

% Weiss 1974 Eq 12 calculating Henry's Law Constant for CO2 for evolving
% salinity and temperature within evolving droplet.
% The concentration of dissolved CO2 and fCO2,the fugacity of  gaseous CO2,  
% then obey the equation [CO2] = K0 × fCO2, where the fugacity is
% virtually equal to the partial pressure, pCO2 (within ~1%). 
% KH units are moles/(L atm)
KH = zeros(1,length(t));
for b=1:length(t) 
    % calculate KH
    KH(b) = exp(A1w + A2w.*(100./(T(b)+273.15)) + A3w.*log((T(b)+273.15)./100) + ...
        S(b).*(B1w + B2w.*((T(b)+273.15)./100) + B3w.*((T(b)+273.15)./100).^2));
end

%% Calculate p/fCO2 Response to Changing T and S using solve_fCO2_combined.m

% Initialize fCO2_corrected as a vector of NaNs (or zeros) to store the results
fCO2_corrected = NaN(1, length(T)); 
fCO2_initial = atmCO2_ppm;
% Initial condition for the first pair of T and S values
fCO2_temp = solve_fCO2_combined(T(1:2), S(1:2), fCO2_initial); 
fCO2_corrected(1) = fCO2_temp(2);

% Loop through each pair of T and S values starting from the second element
for n = 2:length(T)
    % m = n - 1; % Previous index
    % Solve for the current pair of T and S values and update fCO2_corrected
    fCO2_temp = solve_fCO2_combined(T(n-1:n), S(n-1:n), fCO2_corrected(n-1));
    % solve_fCO2_combined outputs [0, value]
    fCO2_corrected(n) = fCO2_temp(2); % save value to vector
end

pCO2_droplet = fCO2_to_pCO2(fCO2_corrected,T')'; % alternative method to calculate pCO2 in droplet

%% Indices of Thermal Equilibrium

% Locate temperature changes
dT = diff(T); % first derivative of temperature vector
change_indices = find(dT ~= 0);

if isempty(change_indices)
    disp('No change detected');
    start_idx = [];
    end_idx = [];
else
    start_idx = change_indices(1);
    end_idx = change_indices(end);
end

%%  Evolution of CO2 Flux 

CO2_Flux_Evol_umol = NaN(1, length(t)); 

for i = 1:length(t)
    % Calculate CO2 gas flux assuming instantaneous equilibration with
    % atmosphere (Andreas et al 2017)
    if i >= start_idx && i <= end_idx
        dpCO2 = pCO2_droplet(i)-atmCO2_ppm; % uatm, allows for influx during thermal equilibrium
    else
        dpCO2 = (max(pCO2_droplet(i) - atmCO2_ppm,0)); 
        % uatm, allows only for efflux during radial equilibrium, prevents influx after all carbon leaves
    end

    CO2_Flux_Evol_umol(i) = dpCO2 * KH(i) * MASS_kg(i); % µmol of CO2 lost/gained
end

CO2_Flux_Evol_umol = CO2_Flux_Evol_umol';

%% Time Aloft (tau_f)
% droplet time aloft for both sea state and wind only parameterizations
[TAU_F] = TAU_F_Vd(r0,WND(wave_ind),HS(wave_ind),US(wave_ind),TairC,TwC,P);
idx_alft=find(t<=TAU_F); % find where the total time is less than the time aloft
idx_alft=idx_alft(end); % choose the last instance

U10_TAU_F = TAU_F_WND_ONLY(r0,WND(wave_ind),TairC,TwC,P);
u10_idx_alft=find(t<=U10_TAU_F); % find where the total time is less than the time aloft
u10_idx_alft=u10_idx_alft(end); % choose the last instance

%% Net Flux Evolution

MMG_CO2 = 44.01; % molecular mass of CO2 in g/mol
RHOA = 1.2922*(273.15/(273.15 + TairC))*(P/1013.25); % Air density in kg/m³
% RHOA = 1.2041; %kg/m³    % density of air at 20C, reference value

    % Calculate Kinematic Flux at each timestep
    % Flux unit conversion from umols lost to mols lost
    MssFluxEvol_mol = CO2_Flux_Evol_umol.*1E-6; % single droplet net mass flux at sea state time aloft (mol CO2/drop)

    % Flux unit conversion from mols CO2 lost to kg CO2 lost
    MssFluxEvol_kg=MssFluxEvol_mol.*MMG_CO2.*(1E-3); % converts mol CO2/drop to kg CO2/drop 
    
    % Unit Conversion from Mass Flux to Kinematic Flux
    KinFluxEvol=MssFluxEvol_kg'./RHOA; % converts mass flux to kinematic flux (kg CO2/drop)/(kg air/m3)

    % interpolates value of kinematic flux at exactly time aloft
    KinFlux_interp = interp1(t, KinFluxEvol, TAU_F, 'linear');
    KinFlux_interp_u10 = interp1(t, KinFluxEvol, U10_TAU_F, 'linear');

    % integrates kinematic flux from start to interpolated value at exactly time aloft
    KinCO2Flux_alft = trapz(t(t <= TAU_F), KinFluxEvol(t <= TAU_F)) + (TAU_F - t(idx_alft)) * KinFlux_interp;
    KinCO2Flux_u10_alft = trapz(t(t <= U10_TAU_F), KinFluxEvol(t <= U10_TAU_F)) + (U10_TAU_F - t(u10_idx_alft)) * KinFlux_interp_u10;

%% K660: Gas Transfer Velocity Evolution and Net Transfer Velocity
    % Calculate Sc using the equation in the Appendix of Wanninkhof 1992: 
   
    Sc=2073.1-(125.62.*T)+(3.6276.*T.^2)-(0.043219.*T.^3);
    Sc_660=(Sc./660).^0.5; % Standardization factor for gas transfer velocity (kd)
    % does not account for salinity spike- not sure if it is useful

    % Calculates the difference in the pCO2 between the ocean and the atmosphere
    % in fractional units (1E-6 factors convert ppm to fractional units)
    dCO2=abs(seaCO2_ppm.*1E-6-atmCO2_ppm.*1E-6); % used in K660 calculations
   
    % Calculate Effective K660 for droplet-mediated CO2 flux:
    kd_660_evol=KinFluxEvol'./(dCO2.*1E-6)./(Sc_660).*100.*3600; 

    % interpolates value of k660 at exactly time aloft
    kd660_interp = interp1(t, kd_660_evol, TAU_F, 'linear');
    kd660_interp_u10 = interp1(t, kd_660_evol, U10_TAU_F, 'linear');

    % integrates k660 from start to interpolated value at exactly time aloft
    kd_660 = trapz(t(t <= TAU_F), kd_660_evol(t <= TAU_F)) + (TAU_F - t(idx_alft)) * kd660_interp;
    kd_660_u10 = trapz(t(t <= U10_TAU_F), kd_660_evol(t <= U10_TAU_F)) + (U10_TAU_F - t(u10_idx_alft)) * kd660_interp_u10;
    
end