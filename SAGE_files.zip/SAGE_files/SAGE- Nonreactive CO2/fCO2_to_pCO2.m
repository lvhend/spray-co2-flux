function pCO2SW_uatm = fCO2_to_pCO2(fCO2SW_uatm, tempSW_C, pres_hPa, tempEQ_C, checks)

% converted to matlab syntax from the python code https://github.com/lukegre/pySeaFlux

    if nargin < 3 || isempty(pres_hPa)
        pres_hPa = 1013.25;
    end
    if nargin < 4 || isempty(tempEQ_C)
        tempEQ_C = tempSW_C;
        tempEQ_was_None = true;
    else
        tempEQ_was_None = false;
    end
    if nargin < 5
        checks = true;
    end

    fCO2sw = fCO2SW_uatm * 1e-6;
    Tsw = tempSW_C + 273.15;
    Teq = tempEQ_C + 273.15;
    Peq = pres_hPa / 1013.25;

    if tempEQ_was_None
        dT = 1.0;
    else
        dT = temperature_correction(Tsw, Teq);
    end

    xCO2eq = fCO2sw .* dT ./ Peq;
    pCO2SW = fCO2sw ./ virial_coeff(Tsw, Peq, xCO2eq, checks);
    pCO2SW_uatm = pCO2SW * 1e6;

% Subfunctions ------------------------------------------------------------

function ve = virial_coeff(temp_K, pres_atm, xCO2_mol, checks)
    if nargin < 4
        checks = false;
    end
    if nargin < 3
        xCO2_mol = [];
    end

    if checks
        if median(temp_K(:)) < 270
            error('Temperature is not in Kelvin');
        end
        if median(pres_atm(:)) > 10
            error('Pressure is not in atmospheres');
        end
    end

    T = temp_K;
    P = pres_atm;
    C = xCO2_mol;
    R = 82.057;

    B = -1636.75 + 12.0408 .* T - 0.0327957 .* T.^2 + 3.16528e-5 .* T.^3;
    d = 57.7 - 0.118 .* T;

    if ~isempty(C)
        x2 = (1 - C).^2;
    else
        x2 = 1;
    end

    ve = exp(P .* (B + 2 .* x2 .* d) ./ (R .* T));
end

function factor = temperature_correction(temp_in, temp_out)
%TEMPERATURE_CORRECTION pCO2 correction factor for temperature changes
%
% This function calculates a correction factor for the temperature 
% difference between intake and equilibrator using the empirical 
% relationship from Takahashi et al. (1993).
%
% Inputs:
%   temp_in  - temperature at which original pCO2 is measured (deg K or deg C)
%   temp_out - temperature to which pCO2 should be adjusted (same unit as temp_in)
%
% Output:
%   factor   - unitless correction factor to multiply pCO2
%
% Reference:
%   Takahashi et al. (1993), Global Biogeochemical Cycles, 7(4), 843–878

    Ti = temp_in;
    To = temp_out;

    factor = exp(0.0433 .* (To - Ti) - 4.35e-5 .* (To.^2 - Ti.^2));


end
%--------------------------------------------------------------------------
end