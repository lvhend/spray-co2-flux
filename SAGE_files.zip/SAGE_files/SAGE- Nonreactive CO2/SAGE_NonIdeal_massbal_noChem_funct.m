function [Evaporation_Parameters,Evolution_Results,Droplet_Net_KinFlux,SSGF_NetCO2Flux]=SAGE_NonIdeal_massbal_noChem_funct(RH,TwC,...
    TairC,wave_ind,HS,EDS,WND,FP,US,WCC,MSS,atmCO2_ppm,seaCO2_ppm)
%% Notes
% This function can only handle one windspeed/wave age at a time.
% For each r0 the CO2 flux for each drop during its time aloft is 
% calculated and integrated over total volume flux using a modified Barr 
% 2022 and the Andreas 1998 sea spray generation function (SSGF). 

%% Input Variables

% A17 inputs:
r0= 10:4:2000;    %Initial radius range of the droplets (μm)
SAL=34;           % Salinity 
P= 1013.25;       % Barometric Pressure (mb)
% RH= 90;         % Relative humidity in %
% TwC= 1.5;       % Water temperature (°C) from https://explore.webodv.awi.de/ocean/carbon/socat/socatv2024/
% TairC= -5;      % Air Temperature (°C)

% CO2SYS inputs
% DIC_initial = 2000;
% pH_initial = 8.1;

% SSGF inputs:
% wave_ind: wave age index, used to select indices in other sea state parameters to ensure the wave ages are all uniform
% HS: significant wave height (m)
% EDS: energy dissipation (W/m^2) 
% WND: wind speed (10 m) 
% FP: peak frequency (1/s)
% US: friction velocity (m/s)
% WCC: whitecap coverage (unitless)
% MSS: mean squared wave slope

% K600 Calculation inputs
% atmCO2_ppm = concentration of CO2 in the atmosphere
% seaCO2_ppm = concentration of CO2 in the surface ocean

%% Individual Physical and Chemical Droplet Evolution by Size Class 

% Preallocated Storage for Results
rows=146; % length of t=getlogarithmictimes function in nonrctv_CO2_flux_drop.m
cols=9; % number of variables, adjust as needed
pages=numel(r0);

Evolution_Results=zeros(rows,cols,pages);
Evaporation_Parameters=zeros(pages,4);
Droplet_Net_KinFlux=zeros(pages,4);

% Calculates net flux per droplet size class

for n=1:length(r0)

    [t,r,S,T,VOL,r_EQ,TAU_F, U10_TAU_F,pCO2,fCO2,...
        CO2_Flux_Evol_umol,KinCO2Flux_alft,KinCO2Flux_u10_alft,...
        kd_660_evol,kd_660,kd_660_u10] = nonrctv_CO2_flux_drop(r0(n),TwC,TairC,...
        RH,SAL,P,wave_ind,HS,WND,US,atmCO2_ppm,seaCO2_ppm);

    Evolution_Results(:,:,n)=[t,r,S,T,VOL',pCO2,fCO2',CO2_Flux_Evol_umol,kd_660_evol];

    Evaporation_Parameters(n,:)= [r0(n), TAU_F, r_EQ, U10_TAU_F];

    Droplet_Net_KinFlux(n,:) = [KinCO2Flux_alft,KinCO2Flux_u10_alft,kd_660,kd_660_u10];
end

% Outputs:
    % t = time (seconds)
    % r = droplet radius (um)
    % S = droplet salinity (psu)
    % T = droplet temperature (C)
    % VOL = droplet volume (um3)
    % TAU_F = sea state dependent time aloft (s)
    % U10_TAU_F = windspeed dependent time aloft (s)
    % r_EQ = droplet radius at full evaporation (um) 
    % TA = total alkalinity (umol/kgSW)
    % DIC = dissolved inorganic carbon (umol/kgSW)
    % pH = droplet pH
    % pCO2 = droplet pCO2 (uatm)
    % fCO2 = droplet fCO2 (uatm)
    % HCO3 = bicarbonate (umol/kgSW)
    % CO3 = carbonate (umol/kgSW)
    % CO2 = CO2 gas concentration (umol/kgSW)
    % genCO2 = CO2 generated within the droplet (umol/kgSW)
    % CO2_Flux_Evol = CO2 gas flux evolution within the droplet (umol/kg)
    % CO2flux_umol_alft = net CO2 gas flux over sea state time aloft for a single droplet
    % CO2flux_umol_u10_alft = net CO2 gas flux over windspeed time aloft for a single droplet

%% SSGF- B22 and A98 Calculation Using Wave Data from WW3 Model

% Barr22 SSGF: m3/(m2 s um)
Barr22=volfluxB22ww3(r0,FP(wave_ind),EDS(wave_ind),WND(wave_ind),WCC(wave_ind),...
    HS(wave_ind),US(wave_ind),MSS(wave_ind),TairC,TwC,SAL,P,RH);

% A98 SSGF: m3/(m2 s um)
A98=volfluxA98(r0,WND(wave_ind));

% calculate wave age for Barr results context
g=9.8; %m/s^2, gravity
CP=g./(2*pi.*FP);% peak phase speed.
WAGE=CP./US; % compute wave age: cp/u*

%% Upscaling the Volume Flux By SSGF

% Plot upscaled flux vs r0. Compare results from SSGFs
VOL_inital_um3 = (4/3).*pi.*r0.^3;
VOL_initial_m3 = VOL_inital_um3.*(1E-6).^3; 
% vector where each number is the inital droplet volume for each size class

% Number of droplets lifted for each r0 by SSGF
Num_B22=Barr22(1:length(r0))./VOL_initial_m3; % (m3/(m2 s um))./(m3/drop) = (drop/(m2 s um))
Num_A98=A98(1:length(r0))./VOL_initial_m3;

%% Upscaling the Carbon Flux By SSGF
% Net flux calculated by multiplying the molar flux for each r0 by the
% number of droplets lifted at that r0

% Net Kinematic Flux by Size Class
% (kg CO2/(kg air/m3) * 1/drop)(drop/(m2 s um)) = (kg CO2/(kg air/m3))/(m2 s um)
radialCO2_Flux_B22 = (Droplet_Net_KinFlux(:,1).*Num_B22'); 
radialCO2_Flux_A98 = (Droplet_Net_KinFlux(:,2).*Num_A98'); 

% Net Flux 
NetFlux_B22=trapz(r0,radialCO2_Flux_B22); % m/s
NetFlux_A98=trapz(r0,radialCO2_Flux_A98);

% Estimated Transfer Velocity 
Net_K660_B22=trapz(r0,Droplet_Net_KinFlux(:,3).*Num_B22'); 
Net_K660_A98=trapz(r0,Droplet_Net_KinFlux(:,4).*Num_A98');

SSGF_NetCO2Flux = [NetFlux_B22',NetFlux_A98',Net_K660_B22',Net_K660_A98',WND(wave_ind),WAGE(wave_ind)];

% (kg CO2/(kg air/m3))/(m2 s) * 1/um integrated over um 
% = (kg CO2/(kg air/m3))/(m2 s)
% = kg CO2

end