function fCO2_corrected = solve_fCO2_combined(T, S, fCO2_initial)

% Uses ODEs to solve the Weiss 1982 equations 1 and 2 correcting fCO2 in
% seawater for temperature and salinity changes

    % Define the ODE for temperature and salinity
    ode_temp = @(t, y) 0.03107 - 2.785E-4 * t - 1.839E-3 * y; % Temperature (T)
    ode_salin = @(S, y) 0.08620 - 1.272E-3 * S; % Salinity (S)
    
    % Initial condition: ln(fCO2) at t = 0 is ln(fCO2_initial)
    y0 = log(fCO2_initial);
    
    % Initialize variables
    fCO2_corrected = zeros(length(T), 1);
    previous_y_temp_values = y0; % Start with the initial y_temp (ln(fCO2_initial))
    previous_y_salin_values = previous_y_temp_values; % Start with the initial y_temp for salinity

    for i = 2:length(T)
        % Check if current T value is the same as the previous one
        if i > 1 && T(i) == T(i-1)
            % If T is the same as the previous one, use the previous solution
            y_temp_values = previous_y_temp_values;
        else
            % Solve the ODE for temperature
            [t_values_temp, y_temp_values] = ode45(ode_temp, [T(i-1) T(i)], previous_y_temp_values); % Solve for current T range
            previous_y_temp_values = y_temp_values(end); % Update the last value for the next iteration
        end
        
        % Check if current S value is the same as the previous one
        if i > 1 && S(i) == S(i-1)
            % If S is the same as the previous one, use the previous solution
            y_salin_values = previous_y_salin_values;
        else
            % Solve the ODE for salinity based on the temperature results
            [S_values_salin, y_salin_values] = ode45(ode_salin, [S(i-1) S(i)], y_temp_values(end)); % Solve for current S range
            previous_y_salin_values = y_salin_values(end); % Update the last value for the next iteration
        end
        
        % Calculate fCO2 from ln(fCO2)
        fCO2_corrected(i) = exp(y_salin_values(end)); % Get the final value of fCO2
    end
end